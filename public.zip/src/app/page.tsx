import Link from "next/link";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 text-white">
      {/* Navigation */}
      <nav className="container mx-auto px-6 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-400 via-blue-500 to-indigo-500 flex items-center justify-center shadow-lg shadow-blue-500/30">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-cyan-400 to-white bg-clip-text text-transparent">
              AI Studio
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <Link
              href="/auth"
              className="px-6 py-2.5 bg-white/10 hover:bg-white/20 rounded-xl font-medium transition-colors border border-white/10"
            >
              Login
            </Link>
            <Link
              href="/auth"
              className="px-6 py-2.5 bg-gradient-to-r from-blue-500 via-blue-600 to-indigo-600 rounded-xl font-medium hover:shadow-lg hover:shadow-blue-500/30 transition-all"
            >
              Get Started
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="container mx-auto px-6 py-20">
        <div className="text-center max-w-4xl mx-auto">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-500/20 rounded-full text-blue-300 text-sm mb-8 border border-blue-500/30">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
            </span>
            Powered by Advanced AI Models ✨
          </div>

          <h2 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            Create{" "}
            <span className="bg-gradient-to-r from-blue-400 via-cyan-400 to-white bg-clip-text text-transparent">
              Stunning Content
            </span>
            <br />
            with AI
          </h2>

          <p className="text-xl text-slate-300 mb-10 max-w-2xl mx-auto">
            Generate images, audio, and videos using state-of-the-art AI. Transform your ideas into reality in seconds.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="/auth"
              className="px-8 py-4 bg-gradient-to-r from-blue-500 via-blue-600 to-indigo-600 rounded-xl font-semibold text-lg hover:shadow-xl hover:shadow-blue-500/30 transition-all hover:-translate-y-1"
            >
              Start Creating for Free ✨
            </Link>
            <button className="px-8 py-4 bg-white/10 hover:bg-white/20 rounded-xl font-semibold text-lg transition-colors flex items-center gap-2 border border-white/10">
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z" />
              </svg>
              Watch Demo
            </button>
          </div>
        </div>

        {/* Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-24">
          <div className="bg-white/5 backdrop-blur-sm border border-blue-500/20 rounded-2xl p-8 hover:bg-white/10 transition-all group hover:-translate-y-1 hover:shadow-xl hover:shadow-blue-500/10">
            <div className="w-14 h-14 rounded-xl bg-gradient-to-r from-blue-500 to-indigo-500 flex items-center justify-center text-2xl mb-6 group-hover:scale-110 transition-transform shadow-lg shadow-blue-500/30">
              🖼️
            </div>
            <h3 className="text-xl font-semibold mb-3">Image Generation</h3>
            <p className="text-slate-400">
              Create stunning visuals from text descriptions. Perfect for art, marketing, and design.
            </p>
          </div>

          <div className="bg-white/5 backdrop-blur-sm border border-cyan-500/20 rounded-2xl p-8 hover:bg-white/10 transition-all group hover:-translate-y-1 hover:shadow-xl hover:shadow-cyan-500/10">
            <div className="w-14 h-14 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 flex items-center justify-center text-2xl mb-6 group-hover:scale-110 transition-transform shadow-lg shadow-cyan-500/30">
              🎵
            </div>
            <h3 className="text-xl font-semibold mb-3">Audio Generation</h3>
            <p className="text-slate-400">
              Generate music, sound effects, and voiceovers. Ideal for podcasts, videos, and games.
            </p>
          </div>

          <div className="bg-white/5 backdrop-blur-sm border border-indigo-500/20 rounded-2xl p-8 hover:bg-white/10 transition-all group hover:-translate-y-1 hover:shadow-xl hover:shadow-indigo-500/10">
            <div className="w-14 h-14 rounded-xl bg-gradient-to-r from-indigo-500 via-blue-500 to-cyan-500 flex items-center justify-center text-2xl mb-6 group-hover:scale-110 transition-transform shadow-lg shadow-indigo-500/30">
              🎬
            </div>
            <h3 className="text-xl font-semibold mb-3">Video Generation</h3>
            <p className="text-slate-400">
              Create videos from prompts. Great for social media, presentations, and storytelling.
            </p>
          </div>
        </div>

        {/* Stats Section */}
        <div className="mt-24 grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { value: "10M+", label: "Images Created" },
            { value: "500K+", label: "Active Users" },
            { value: "99.9%", label: "Uptime" },
            { value: "4.9/5", label: "User Rating" },
          ].map((stat, index) => (
            <div key={index} className="text-center">
              <p className="text-4xl font-bold bg-gradient-to-r from-blue-400 via-cyan-400 to-white bg-clip-text text-transparent">
                {stat.value}
              </p>
              <p className="text-slate-400 mt-2">{stat.label}</p>
            </div>
          ))}
        </div>
      </main>

      {/* Footer */}
      <footer className="container mx-auto px-6 py-12 border-t border-blue-500/20 mt-20">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-slate-400">© 2026 AI Studio. All rights reserved.</p>
          <div className="flex items-center gap-6 text-slate-400">
            <a href="#" className="hover:text-emerald-400 transition-colors">Privacy</a>
            <a href="#" className="hover:text-emerald-400 transition-colors">Terms</a>
            <a href="#" className="hover:text-emerald-400 transition-colors">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}