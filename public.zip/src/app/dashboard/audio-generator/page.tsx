"use client";

import { useState, useRef } from "react";

const genreOptions = [
  { id: "ambient", name: "Ambient", emoji: "🌌", color: "from-indigo-500 to-purple-600" },
  { id: "electronic", name: "Electronic", emoji: "🎹", color: "from-cyan-500 to-blue-600" },
  { id: "cinematic", name: "Cinematic", emoji: "🎬", color: "from-amber-500 to-orange-600" },
  { id: "jazz", name: "Jazz", emoji: "🎷", color: "from-yellow-500 to-amber-600" },
  { id: "classical", name: "Classical", emoji: "🎻", color: "from-rose-500 to-pink-600" },
  { id: "pop", name: "Pop", emoji: "🎤", color: "from-fuchsia-500 to-purple-600" },
];

const moodOptions = [
  { id: "happy", name: "Happy", icon: "☀️" },
  { id: "sad", name: "Melancholic", icon: "🌧️" },
  { id: "energetic", name: "Energetic", icon: "⚡" },
  { id: "calm", name: "Calm", icon: "🍃" },
  { id: "dark", name: "Dark", icon: "🌑" },
  { id: "uplifting", name: "Uplifting", icon: "🚀" },
];

const durationOptions = [
  { id: "short", name: "30s", value: 30 },
  { id: "medium", name: "1 min", value: 60 },
  { id: "long", name: "2 min", value: 120 },
  { id: "extended", name: "3 min", value: 180 },
];

interface GeneratedAudio {
  id: number;
  name: string;
  duration: string;
  genre: string;
  mood: string;
}

export default function AudioGeneratorPage() {
  const [prompt, setPrompt] = useState("");
  const [selectedGenre, setSelectedGenre] = useState("ambient");
  const [selectedMood, setSelectedMood] = useState("calm");
  const [selectedDuration, setSelectedDuration] = useState("medium");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedAudios, setGeneratedAudios] = useState<GeneratedAudio[]>([]);
  const [playingId, setPlayingId] = useState<number | null>(null);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [activeTab, setActiveTab] = useState<"prompt" | "upload">("prompt");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleGenerate = async () => {
    if (!prompt.trim() && !uploadedFile) return;
    
    setIsGenerating(true);
    await new Promise((resolve) => setTimeout(resolve, 2500));
    
    const newAudio: GeneratedAudio = {
      id: Date.now(),
      name: uploadedFile ? uploadedFile.name : prompt.slice(0, 30) + (prompt.length > 30 ? "..." : ""),
      duration: durationOptions.find((d) => d.id === selectedDuration)?.name || "1 min",
      genre: genreOptions.find((g) => g.id === selectedGenre)?.name || "Ambient",
      mood: moodOptions.find((m) => m.id === selectedMood)?.name || "Calm",
    };
    
    setGeneratedAudios([newAudio, ...generatedAudios]);
    setIsGenerating(false);
  };

  const togglePlay = (id: number) => {
    setPlayingId(playingId === id ? null : id);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFile(file);
    }
  };

  const removeFile = () => {
    setUploadedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center shadow-lg shadow-purple-500/30">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
              </svg>
            </div>
            Audio Generator
          </h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1">Create AI-powered music and audio tracks</p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 bg-purple-500/10 dark:bg-purple-500/20 rounded-xl border border-purple-500/20">
          <svg className="w-5 h-5 text-purple-600 dark:text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
          <span className="font-medium text-purple-700 dark:text-purple-300">
            {durationOptions.find((d) => d.id === selectedDuration)?.value || 60} credits
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-5 gap-6">
        {/* Left Panel - Input Options */}
        <div className="xl:col-span-2 space-y-6">
          {/* Input Type Tabs */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-none overflow-hidden">
            <div className="flex border-b border-slate-200 dark:border-slate-800">
              <button
                onClick={() => setActiveTab("prompt")}
                className={`flex-1 px-6 py-4 text-sm font-medium transition-all ${
                  activeTab === "prompt"
                    ? "bg-gradient-to-r from-purple-500/10 to-pink-500/10 text-purple-700 dark:text-purple-300 border-b-2 border-purple-500"
                    : "text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
                }`}
              >
                <div className="flex items-center justify-center gap-2">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                  </svg>
                  Text Prompt
                </div>
              </button>
              <button
                onClick={() => setActiveTab("upload")}
                className={`flex-1 px-6 py-4 text-sm font-medium transition-all ${
                  activeTab === "upload"
                    ? "bg-gradient-to-r from-purple-500/10 to-pink-500/10 text-purple-700 dark:text-purple-300 border-b-2 border-purple-500"
                    : "text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
                }`}
              >
                <div className="flex items-center justify-center gap-2">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                  </svg>
                  Upload Audio
                </div>
              </button>
            </div>

            <div className="p-6">
              {activeTab === "prompt" ? (
                <div className="space-y-4">
                  <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300">
                    Describe your audio
                  </label>
                  <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="An uplifting electronic track with synth pads, deep bass, and a catchy melody that builds to an epic drop..."
                    className="w-full h-36 px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:bg-white dark:focus:bg-slate-800 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all outline-none resize-none text-slate-700 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-500"
                  />
                </div>
              ) : (
                <div className="space-y-4">
                  <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300">
                    Upload reference audio
                  </label>
                  {!uploadedFile ? (
                    <div
                      onClick={() => fileInputRef.current?.click()}
                      className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-8 text-center hover:border-purple-500 dark:hover:border-purple-500 transition-colors cursor-pointer group"
                    >
                      <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-purple-500/20 to-pink-500/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                        <svg className="w-8 h-8 text-purple-600 dark:text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
                        </svg>
                      </div>
                      <p className="text-slate-600 dark:text-slate-400 font-medium">Click to upload audio file</p>
                      <p className="text-slate-400 dark:text-slate-500 text-sm mt-1">MP3, WAV, or M4A up to 50MB</p>
                    </div>
                  ) : (
                    <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 dark:from-purple-500/20 dark:to-pink-500/20 rounded-xl p-4 flex items-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center">
                        <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
                        </svg>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-slate-800 dark:text-slate-200 truncate">{uploadedFile.name}</p>
                        <p className="text-sm text-slate-500 dark:text-slate-400">
                          {(uploadedFile.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                      <button
                        onClick={removeFile}
                        className="p-2 hover:bg-white/50 dark:hover:bg-slate-800 rounded-lg transition-colors"
                      >
                        <svg className="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      </button>
                    </div>
                  )}
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="audio/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Settings Card */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-none p-6 space-y-6">
            {/* Genre Selection */}
            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3">
                Genre
              </label>
              <div className="grid grid-cols-3 gap-2">
                {genreOptions.map((genre) => (
                  <button
                    key={genre.id}
                    onClick={() => setSelectedGenre(genre.id)}
                    className={`p-3 rounded-xl border-2 transition-all ${
                      selectedGenre === genre.id
                        ? `border-transparent bg-gradient-to-r ${genre.color} text-white shadow-lg`
                        : "border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 bg-white dark:bg-slate-800"
                    }`}
                  >
                    <span className="text-xl">{genre.emoji}</span>
                    <p className={`text-xs mt-1 font-medium ${selectedGenre === genre.id ? "text-white" : "text-slate-600 dark:text-slate-400"}`}>
                      {genre.name}
                    </p>
                  </button>
                ))}
              </div>
            </div>

            {/* Mood Selection */}
            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3">
                Mood
              </label>
              <div className="flex flex-wrap gap-2">
                {moodOptions.map((mood) => (
                  <button
                    key={mood.id}
                    onClick={() => setSelectedMood(mood.id)}
                    className={`px-4 py-2 rounded-xl text-sm font-medium transition-all flex items-center gap-2 ${
                      selectedMood === mood.id
                        ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg shadow-purple-500/25"
                        : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
                    }`}
                  >
                    <span>{mood.icon}</span>
                    {mood.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Duration Selection */}
            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3">
                Duration
              </label>
              <div className="grid grid-cols-4 gap-2">
                {durationOptions.map((duration) => (
                  <button
                    key={duration.id}
                    onClick={() => setSelectedDuration(duration.id)}
                    className={`p-3 rounded-xl border-2 transition-all text-center ${
                      selectedDuration === duration.id
                        ? "border-purple-500 bg-purple-500/10 dark:bg-purple-500/20"
                        : "border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600"
                    }`}
                  >
                    <p className={`font-semibold ${selectedDuration === duration.id ? "text-purple-700 dark:text-purple-300" : "text-slate-700 dark:text-slate-300"}`}>
                      {duration.name}
                    </p>
                  </button>
                ))}
              </div>
            </div>

            {/* Generate Button */}
            <button
              onClick={handleGenerate}
              disabled={(!prompt.trim() && !uploadedFile) || isGenerating}
              className="w-full py-4 bg-gradient-to-r from-purple-600 via-pink-600 to-purple-600 bg-size-200 bg-pos-0 hover:bg-pos-100 text-white font-semibold rounded-xl transition-all duration-500 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-lg shadow-purple-500/25 hover:shadow-xl hover:shadow-purple-500/30"
            >
              {isGenerating ? (
                <>
                  <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  <span>Generating Audio...</span>
                </>
              ) : (
                <>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                  <span>Generate Audio</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Panel - Generated Audio */}
        <div className="xl:col-span-3">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-none min-h-[700px]">
            <div className="p-6 border-b border-slate-200 dark:border-slate-800">
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Generated Audio</h2>
              <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">Your AI-generated audio tracks</p>
            </div>
            
            {generatedAudios.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-[500px] text-slate-400 dark:text-slate-500">
                <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-purple-500/10 to-pink-500/10 dark:from-purple-500/20 dark:to-pink-500/20 flex items-center justify-center mb-4">
                  <svg className="w-12 h-12 text-purple-500/50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
                  </svg>
                </div>
                <p className="text-lg font-medium">No audio generated yet</p>
                <p className="text-sm">Enter a prompt or upload audio to get started</p>
              </div>
            ) : (
              <div className="p-6 space-y-4">
                {generatedAudios.map((audio) => (
                  <div
                    key={audio.id}
                    className="group bg-gradient-to-r from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-800/50 rounded-2xl p-5 border border-slate-200 dark:border-slate-700 hover:border-purple-500/50 dark:hover:border-purple-500/50 transition-all hover:shadow-lg"
                  >
                    <div className="flex items-center gap-4">
                      {/* Play Button */}
                      <button
                        onClick={() => togglePlay(audio.id)}
                        className={`w-16 h-16 rounded-2xl flex items-center justify-center transition-all shadow-lg ${
                          playingId === audio.id
                            ? "bg-gradient-to-br from-purple-600 to-pink-600 text-white shadow-purple-500/30"
                            : "bg-white dark:bg-slate-700 text-purple-600 dark:text-purple-400 hover:scale-105 shadow-slate-200/50 dark:shadow-none"
                        }`}
                      >
                        {playingId === audio.id ? (
                          <svg className="w-7 h-7" fill="currentColor" viewBox="0 0 24 24">
                            <rect x="6" y="4" width="4" height="16" rx="1" />
                            <rect x="14" y="4" width="4" height="16" rx="1" />
                          </svg>
                        ) : (
                          <svg className="w-7 h-7 ml-1" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M8 5v14l11-7z" />
                          </svg>
                        )}
                      </button>

                      {/* Audio Info */}
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-slate-800 dark:text-white truncate">{audio.name}</p>
                        <div className="flex items-center gap-3 text-sm text-slate-500 dark:text-slate-400 mt-1">
                          <span className="flex items-center gap-1">
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            {audio.duration}
                          </span>
                          <span>•</span>
                          <span>{audio.genre}</span>
                          <span>•</span>
                          <span>{audio.mood}</span>
                        </div>
                        
                        {/* Waveform */}
                        <div className="mt-3 flex items-center gap-0.5 h-10">
                          {Array.from({ length: 50 }).map((_, i) => (
                            <div
                              key={i}
                              className={`w-1 rounded-full transition-all duration-150 ${
                                playingId === audio.id
                                  ? "bg-gradient-to-t from-purple-600 to-pink-500"
                                  : "bg-slate-300 dark:bg-slate-600"
                              }`}
                              style={{
                                height: `${20 + Math.random() * 80}%`,
                                animationDelay: `${i * 30}ms`,
                                animation: playingId === audio.id ? "pulse 0.5s ease-in-out infinite" : "none",
                              }}
                            />
                          ))}
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="p-3 bg-white dark:bg-slate-700 hover:bg-slate-100 dark:hover:bg-slate-600 rounded-xl transition-colors shadow-sm">
                          <svg className="w-5 h-5 text-slate-600 dark:text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                          </svg>
                        </button>
                        <button className="p-3 bg-white dark:bg-slate-700 hover:bg-slate-100 dark:hover:bg-slate-600 rounded-xl transition-colors shadow-sm">
                          <svg className="w-5 h-5 text-slate-600 dark:text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                          </svg>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
