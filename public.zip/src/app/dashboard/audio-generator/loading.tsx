export default function AudioGeneratorLoading() {
  return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <div className="flex flex-col items-center gap-4">
        {/* Audio Wave Animation */}
        <div className="flex items-end gap-1 h-16">
          {[...Array(5)].map((_, i) => (
            <div
              key={i}
              className="w-3 bg-gradient-to-t from-blue-600 to-indigo-500 rounded-full animate-pulse"
              style={{
                height: `${20 + Math.random() * 40}px`,
                animationDelay: `${i * 0.1}s`,
                animationDuration: "0.8s",
              }}
            ></div>
          ))}
        </div>
        {/* Loading Text */}
        <p className="text-slate-600 dark:text-blue-300 font-medium">
          Loading Audio Generator...
        </p>
      </div>
    </div>
  );
}
