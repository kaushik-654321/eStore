export default function VideoGeneratorLoading() {
  return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <div className="flex flex-col items-center gap-4">
        {/* Video Icon with Animation */}
        <div className="relative">
          <div className="w-20 h-20 bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-2xl flex items-center justify-center">
            <svg
              className="w-10 h-10 text-blue-500"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"
              />
            </svg>
          </div>
          {/* Pulsing ring */}
          <div className="absolute -inset-2 border-4 border-blue-500/30 rounded-2xl animate-ping"></div>
        </div>
        {/* Loading Text */}
        <p className="text-slate-600 dark:text-blue-300 font-medium">
          Loading Video Generator...
        </p>
      </div>
    </div>
  );
}
