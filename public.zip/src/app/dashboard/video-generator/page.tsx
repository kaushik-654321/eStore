"use client";

import { useState, useRef } from "react";

const aspectOptions = [
  { id: "16:9", name: "16:9", desc: "Widescreen", icon: "📺" },
  { id: "9:16", name: "9:16", desc: "Portrait", icon: "📱" },
  { id: "1:1", name: "1:1", desc: "Square", icon: "⬜" },
  { id: "4:3", name: "4:3", desc: "Standard", icon: "🖥️" },
];

const qualityOptions = [
  { id: "720p", name: "720p", desc: "HD", credits: 50 },
  { id: "1080p", name: "1080p", desc: "Full HD", credits: 100 },
  { id: "4k", name: "4K", desc: "Ultra HD", credits: 200 },
];

const styleOptions = [
  { id: "realistic", name: "Realistic", emoji: "🎬", color: "from-blue-500 to-cyan-600" },
  { id: "animated", name: "Animated", emoji: "🎨", color: "from-pink-500 to-rose-600" },
  { id: "cinematic", name: "Cinematic", emoji: "🎥", color: "from-amber-500 to-orange-600" },
  { id: "3d", name: "3D Render", emoji: "🎲", color: "from-violet-500 to-purple-600" },
];

interface GeneratedVideo {
  id: number;
  name: string;
  duration: string;
  quality: string;
  style: string;
  status: "processing" | "completed" | "failed";
  progress: number;
  thumbnail?: string;
}

interface UploadedFile {
  file: File;
  preview: string;
  type: "image" | "video";
}

export default function VideoGeneratorPage() {
  const [prompt, setPrompt] = useState("");
  const [selectedAspect, setSelectedAspect] = useState("16:9");
  const [selectedQuality, setSelectedQuality] = useState("1080p");
  const [selectedStyle, setSelectedStyle] = useState("cinematic");
  const [duration, setDuration] = useState(5);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedVideos, setGeneratedVideos] = useState<GeneratedVideo[]>([]);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [activeTab, setActiveTab] = useState<"prompt" | "upload">("prompt");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleGenerate = async () => {
    if (!prompt.trim() && uploadedFiles.length === 0) return;
    
    const newVideo: GeneratedVideo = {
      id: Date.now(),
      name: uploadedFiles.length > 0 
        ? `Video from ${uploadedFiles.length} file(s)`
        : prompt.slice(0, 40) + (prompt.length > 40 ? "..." : ""),
      duration: `${duration}s`,
      quality: selectedQuality,
      style: styleOptions.find((s) => s.id === selectedStyle)?.name || "Cinematic",
      status: "processing",
      progress: 0,
    };
    
    setGeneratedVideos([newVideo, ...generatedVideos]);
    setIsGenerating(true);

    const interval = setInterval(() => {
      setGeneratedVideos((prev) =>
        prev.map((v) =>
          v.id === newVideo.id
            ? {
                ...v,
                progress: Math.min(v.progress + 10, 100),
                status: v.progress >= 90 ? "completed" : "processing",
              }
            : v
        )
      );
    }, 500);

    setTimeout(() => {
      clearInterval(interval);
      setGeneratedVideos((prev) =>
        prev.map((v) =>
          v.id === newVideo.id ? { ...v, progress: 100, status: "completed" } : v
        )
      );
      setIsGenerating(false);
    }, 5000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const newFiles: UploadedFile[] = files.map((file) => ({
      file,
      preview: URL.createObjectURL(file),
      type: file.type.startsWith("video/") ? "video" : "image",
    }));
    setUploadedFiles([...uploadedFiles, ...newFiles]);
  };

  const removeFile = (index: number) => {
    const newFiles = [...uploadedFiles];
    URL.revokeObjectURL(newFiles[index].preview);
    newFiles.splice(index, 1);
    setUploadedFiles(newFiles);
  };

  const totalCredits = (qualityOptions.find((q) => q.id === selectedQuality)?.credits || 100) * (duration / 5);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center shadow-lg shadow-orange-500/30">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
            </div>
            Video Generator
          </h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1">Create stunning AI-powered videos</p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 bg-orange-500/10 dark:bg-orange-500/20 rounded-xl border border-orange-500/20">
          <svg className="w-5 h-5 text-orange-600 dark:text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
          <span className="font-medium text-orange-700 dark:text-orange-300">{Math.round(totalCredits)} credits</span>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-5 gap-6">
        {/* Left Panel - Input Options */}
        <div className="xl:col-span-2 space-y-6">
          {/* Input Type Tabs */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-none overflow-hidden">
            <div className="flex border-b border-slate-200 dark:border-slate-800">
              <button
                onClick={() => setActiveTab("prompt")}
                className={`flex-1 px-6 py-4 text-sm font-medium transition-all ${
                  activeTab === "prompt"
                    ? "bg-gradient-to-r from-orange-500/10 to-red-500/10 text-orange-700 dark:text-orange-300 border-b-2 border-orange-500"
                    : "text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
                }`}
              >
                <div className="flex items-center justify-center gap-2">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                  </svg>
                  Text Prompt
                </div>
              </button>
              <button
                onClick={() => setActiveTab("upload")}
                className={`flex-1 px-6 py-4 text-sm font-medium transition-all ${
                  activeTab === "upload"
                    ? "bg-gradient-to-r from-orange-500/10 to-red-500/10 text-orange-700 dark:text-orange-300 border-b-2 border-orange-500"
                    : "text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
                }`}
              >
                <div className="flex items-center justify-center gap-2">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                  </svg>
                  Upload Media
                </div>
              </button>
            </div>

            <div className="p-6">
              {activeTab === "prompt" ? (
                <div className="space-y-4">
                  <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300">
                    Describe your video
                  </label>
                  <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="A cinematic drone shot flying over a tropical beach at golden hour, with crystal clear turquoise water and palm trees swaying in the breeze..."
                    className="w-full h-36 px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:bg-white dark:focus:bg-slate-800 focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 transition-all outline-none resize-none text-slate-700 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-500"
                  />
                </div>
              ) : (
                <div className="space-y-4">
                  <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300">
                    Upload images or videos to transform
                  </label>
                  
                  {uploadedFiles.length === 0 ? (
                    <div
                      onClick={() => fileInputRef.current?.click()}
                      className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-8 text-center hover:border-orange-500 dark:hover:border-orange-500 transition-colors cursor-pointer group"
                    >
                      <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-orange-500/20 to-red-500/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                        <svg className="w-8 h-8 text-orange-600 dark:text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                        </svg>
                      </div>
                      <p className="text-slate-600 dark:text-slate-400 font-medium">Click to upload media files</p>
                      <p className="text-slate-400 dark:text-slate-500 text-sm mt-1">Images (PNG, JPG) or Videos (MP4, MOV)</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div className="grid grid-cols-3 gap-3">
                        {uploadedFiles.map((file, index) => (
                          <div key={index} className="relative group aspect-video rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800">
                            {file.type === "image" ? (
                              <img src={file.preview} alt="" className="w-full h-full object-cover" />
                            ) : (
                              <video src={file.preview} className="w-full h-full object-cover" />
                            )}
                            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                              <button
                                onClick={() => removeFile(index)}
                                className="p-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
                              >
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                </svg>
                              </button>
                            </div>
                            <span className="absolute bottom-1 right-1 px-2 py-0.5 bg-black/70 text-white text-xs rounded">
                              {file.type === "image" ? "IMG" : "VID"}
                            </span>
                          </div>
                        ))}
                        <button
                          onClick={() => fileInputRef.current?.click()}
                          className="aspect-video rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-700 flex items-center justify-center hover:border-orange-500 transition-colors"
                        >
                          <svg className="w-8 h-8 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                          </svg>
                        </button>
                      </div>
                    </div>
                  )}
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*,video/*"
                    multiple
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Settings Card */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-none p-6 space-y-6">
            {/* Style Selection */}
            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3">
                Visual Style
              </label>
              <div className="grid grid-cols-2 gap-3">
                {styleOptions.map((style) => (
                  <button
                    key={style.id}
                    onClick={() => setSelectedStyle(style.id)}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      selectedStyle === style.id
                        ? `border-transparent bg-gradient-to-r ${style.color} text-white shadow-lg`
                        : "border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 bg-white dark:bg-slate-800"
                    }`}
                  >
                    <span className="text-2xl">{style.emoji}</span>
                    <p className={`text-sm mt-2 font-medium ${selectedStyle === style.id ? "text-white" : "text-slate-600 dark:text-slate-400"}`}>
                      {style.name}
                    </p>
                  </button>
                ))}
              </div>
            </div>

            {/* Aspect Ratio */}
            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3">
                Aspect Ratio
              </label>
              <div className="grid grid-cols-4 gap-2">
                {aspectOptions.map((aspect) => (
                  <button
                    key={aspect.id}
                    onClick={() => setSelectedAspect(aspect.id)}
                    className={`p-3 rounded-xl border-2 transition-all text-center ${
                      selectedAspect === aspect.id
                        ? "border-orange-500 bg-orange-500/10 dark:bg-orange-500/20"
                        : "border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600"
                    }`}
                  >
                    <span className="text-lg">{aspect.icon}</span>
                    <p className={`text-xs mt-1 font-semibold ${selectedAspect === aspect.id ? "text-orange-700 dark:text-orange-300" : "text-slate-700 dark:text-slate-300"}`}>
                      {aspect.name}
                    </p>
                  </button>
                ))}
              </div>
            </div>

            {/* Quality Selection */}
            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3">
                Quality
              </label>
              <div className="grid grid-cols-3 gap-2">
                {qualityOptions.map((quality) => (
                  <button
                    key={quality.id}
                    onClick={() => setSelectedQuality(quality.id)}
                    className={`p-3 rounded-xl border-2 transition-all text-center ${
                      selectedQuality === quality.id
                        ? "border-orange-500 bg-orange-500/10 dark:bg-orange-500/20"
                        : "border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600"
                    }`}
                  >
                    <p className={`font-semibold ${selectedQuality === quality.id ? "text-orange-700 dark:text-orange-300" : "text-slate-700 dark:text-slate-300"}`}>
                      {quality.name}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{quality.desc}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Duration Slider */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <label className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                  Duration
                </label>
                <span className="text-sm font-bold text-orange-600 dark:text-orange-400">{duration} seconds</span>
              </div>
              <input
                type="range"
                min="3"
                max="30"
                value={duration}
                onChange={(e) => setDuration(parseInt(e.target.value))}
                className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-orange-600"
              />
              <div className="flex justify-between text-xs text-slate-500 mt-2">
                <span>3s</span>
                <span>15s</span>
                <span>30s</span>
              </div>
            </div>

            {/* Generate Button */}
            <button
              onClick={handleGenerate}
              disabled={(!prompt.trim() && uploadedFiles.length === 0) || isGenerating}
              className="w-full py-4 bg-gradient-to-r from-orange-600 via-red-600 to-orange-600 bg-size-200 bg-pos-0 hover:bg-pos-100 text-white font-semibold rounded-xl transition-all duration-500 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-lg shadow-orange-500/25 hover:shadow-xl hover:shadow-orange-500/30"
            >
              {isGenerating ? (
                <>
                  <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  <span>Generating Video...</span>
                </>
              ) : (
                <>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                  <span>Generate Video</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Panel - Generated Videos */}
        <div className="xl:col-span-3">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-none min-h-[700px]">
            <div className="p-6 border-b border-slate-200 dark:border-slate-800">
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Generated Videos</h2>
              <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">Your AI-generated video creations</p>
            </div>
            
            {generatedVideos.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-[500px] text-slate-400 dark:text-slate-500">
                <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-orange-500/10 to-red-500/10 dark:from-orange-500/20 dark:to-red-500/20 flex items-center justify-center mb-4">
                  <svg className="w-12 h-12 text-orange-500/50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                </div>
                <p className="text-lg font-medium">No videos generated yet</p>
                <p className="text-sm">Enter a prompt or upload media to get started</p>
              </div>
            ) : (
              <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                {generatedVideos.map((video) => (
                  <div
                    key={video.id}
                    className="group bg-slate-50 dark:bg-slate-800 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 hover:border-orange-500/50 dark:hover:border-orange-500/50 transition-all hover:shadow-lg"
                  >
                    {/* Video Preview */}
                    <div className="aspect-video bg-gradient-to-br from-slate-800 to-slate-900 relative flex items-center justify-center overflow-hidden">
                      {video.status === "processing" ? (
                        <div className="text-center">
                          <div className="relative w-20 h-20 mx-auto mb-3">
                            <svg className="w-20 h-20 transform -rotate-90">
                              <circle
                                cx="40"
                                cy="40"
                                r="36"
                                stroke="currentColor"
                                strokeWidth="4"
                                fill="none"
                                className="text-slate-700"
                              />
                              <circle
                                cx="40"
                                cy="40"
                                r="36"
                                stroke="url(#gradient)"
                                strokeWidth="4"
                                fill="none"
                                strokeLinecap="round"
                                strokeDasharray={`${video.progress * 2.26} 226`}
                                className="transition-all duration-300"
                              />
                              <defs>
                                <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                                  <stop offset="0%" stopColor="#f97316" />
                                  <stop offset="100%" stopColor="#ef4444" />
                                </linearGradient>
                              </defs>
                            </svg>
                            <span className="absolute inset-0 flex items-center justify-center text-white font-bold">
                              {video.progress}%
                            </span>
                          </div>
                          <p className="text-white font-medium">Processing...</p>
                          <p className="text-slate-400 text-sm">Estimated: {Math.ceil((100 - video.progress) / 20)}s remaining</p>
                        </div>
                      ) : (
                        <>
                          <div className="absolute inset-0 bg-gradient-to-br from-orange-600/20 to-red-600/20" />
                          <img
                            src={`https://placehold.co/640x360/1e293b/ffffff?text=${encodeURIComponent(video.style)}`}
                            alt="Video preview"
                            className="w-full h-full object-cover"
                          />
                          <button className="absolute inset-0 flex items-center justify-center bg-black/30 hover:bg-black/40 transition-colors group/play">
                            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center group-hover/play:scale-110 transition-transform shadow-xl shadow-orange-500/30">
                              <svg className="w-8 h-8 text-white ml-1" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M8 5v14l11-7z" />
                              </svg>
                            </div>
                          </button>
                        </>
                      )}
                      
                      {/* Duration Badge */}
                      <span className="absolute bottom-3 right-3 px-2.5 py-1 bg-black/70 text-white text-xs font-medium rounded-lg backdrop-blur-sm">
                        {video.duration}
                      </span>
                      
                      {/* Quality Badge */}
                      <span className="absolute top-3 left-3 px-2.5 py-1 bg-gradient-to-r from-orange-500 to-red-500 text-white text-xs font-medium rounded-lg">
                        {video.quality}
                      </span>
                    </div>

                    {/* Video Info */}
                    <div className="p-4">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <p className="font-semibold text-slate-800 dark:text-white line-clamp-2">{video.name}</p>
                        <span
                          className={`px-2.5 py-1 rounded-lg text-xs font-medium shrink-0 ${
                            video.status === "completed"
                              ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                              : video.status === "processing"
                              ? "bg-amber-500/10 text-amber-600 dark:text-amber-400"
                              : "bg-red-500/10 text-red-600 dark:text-red-400"
                          }`}
                        >
                          {video.status === "completed" ? "✓ Ready" : video.status === "processing" ? "Processing" : "Failed"}
                        </span>
                      </div>
                      
                      <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
                        <span>{video.style}</span>
                        <span>•</span>
                        <span>{video.quality}</span>
                      </div>

                      {/* Actions */}
                      {video.status === "completed" && (
                        <div className="flex items-center gap-2 mt-4">
                          <button className="flex-1 py-2.5 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 rounded-xl text-sm font-medium text-slate-700 dark:text-slate-200 transition-colors">
                            Preview
                          </button>
                          <button className="flex-1 py-2.5 bg-gradient-to-r from-orange-500 to-red-500 hover:shadow-lg hover:shadow-orange-500/25 rounded-xl text-sm font-medium text-white transition-all">
                            Download
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
