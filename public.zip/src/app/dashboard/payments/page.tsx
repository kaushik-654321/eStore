"use client";

import { useState } from "react";

interface TokenPackage {
  id: string;
  name: string;
  tokens: number;
  price: number;
  popular?: boolean;
  discount?: string;
  features: string[];
}

interface PaymentHistory {
  id: string;
  date: string;
  package: string;
  tokens: number;
  amount: number;
  status: "completed" | "pending" | "failed";
  method: string;
}

const tokenPackages: TokenPackage[] = [
  {
    id: "starter",
    name: "Starter",
    tokens: 100,
    price: 9.99,
    features: ["100 AI Credits", "Image Generation", "Basic Support"],
  },
  {
    id: "pro",
    name: "Pro",
    tokens: 500,
    price: 39.99,
    popular: true,
    discount: "20% OFF",
    features: ["500 AI Credits", "All Generators", "Priority Support", "HD Exports"],
  },
  {
    id: "business",
    name: "Business",
    tokens: 1500,
    price: 99.99,
    discount: "33% OFF",
    features: ["1500 AI Credits", "All Generators", "24/7 Support", "4K Exports", "API Access"],
  },
  {
    id: "enterprise",
    name: "Enterprise",
    tokens: 5000,
    price: 249.99,
    discount: "50% OFF",
    features: ["5000 AI Credits", "Unlimited Access", "Dedicated Support", "8K Exports", "API Access", "Custom Models"],
  },
];

const paymentHistory: PaymentHistory[] = [
  {
    id: "PAY-001",
    date: "2026-03-05",
    package: "Pro",
    tokens: 500,
    amount: 39.99,
    status: "completed",
    method: "Visa •••• 4242",
  },
  {
    id: "PAY-002",
    date: "2026-02-15",
    package: "Starter",
    tokens: 100,
    amount: 9.99,
    status: "completed",
    method: "PayPal",
  },
  {
    id: "PAY-003",
    date: "2026-02-01",
    package: "Pro",
    tokens: 500,
    amount: 39.99,
    status: "completed",
    method: "Mastercard •••• 5555",
  },
  {
    id: "PAY-004",
    date: "2026-01-20",
    package: "Business",
    tokens: 1500,
    amount: 99.99,
    status: "failed",
    method: "Visa •••• 1234",
  },
  {
    id: "PAY-005",
    date: "2026-01-10",
    package: "Starter",
    tokens: 100,
    amount: 9.99,
    status: "completed",
    method: "PayPal",
  },
];

export default function PaymentsPage() {
  const [selectedPackage, setSelectedPackage] = useState<string | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [activeTab, setActiveTab] = useState<"packages" | "history">("packages");

  const handleBuyTokens = (packageId: string) => {
    setSelectedPackage(packageId);
    setShowPaymentModal(true);
  };

  const getStatusColor = (status: PaymentHistory["status"]) => {
    switch (status) {
      case "completed":
        return "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-400";
      case "pending":
        return "bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-400";
      case "failed":
        return "bg-red-100 text-red-700 dark:bg-red-500/20 dark:text-red-400";
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br from-amber-500 via-orange-500 to-rose-500 flex items-center justify-center shadow-lg shadow-orange-500/30">
              <svg className="w-5 h-5 sm:w-6 sm:h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
              </svg>
            </div>
            Payments & Tokens ✨
          </h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1">Buy tokens for AI generation</p>
        </div>
        
        {/* Current Balance */}
        <div className="flex items-center gap-3 px-4 sm:px-6 py-3 sm:py-4 bg-gradient-to-r from-violet-500/10 to-fuchsia-500/10 dark:from-violet-500/20 dark:to-fuchsia-500/20 rounded-2xl border border-violet-500/20">
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center shadow-lg shadow-violet-500/30">
            <svg className="w-5 h-5 sm:w-6 sm:h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <div>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">Current Balance</p>
            <p className="text-xl sm:text-2xl font-bold text-violet-700 dark:text-violet-300">250 Credits</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-violet-100 dark:bg-violet-500/20 rounded-xl w-full sm:w-fit">
        <button
          onClick={() => setActiveTab("packages")}
          className={`flex-1 sm:flex-none px-4 sm:px-6 py-2.5 rounded-lg font-medium transition-all ${
            activeTab === "packages"
              ? "bg-white dark:bg-slate-800 text-violet-700 dark:text-violet-300 shadow-sm"
              : "text-violet-600 dark:text-violet-400 hover:text-violet-800 dark:hover:text-violet-200"
          }`}
        >
          Buy Tokens
        </button>
        <button
          onClick={() => setActiveTab("history")}
          className={`flex-1 sm:flex-none px-4 sm:px-6 py-2.5 rounded-lg font-medium transition-all ${
            activeTab === "history"
              ? "bg-white dark:bg-slate-800 text-violet-700 dark:text-violet-300 shadow-sm"
              : "text-violet-600 dark:text-violet-400 hover:text-violet-800 dark:hover:text-violet-200"
          }`}
        >
          Payment History
        </button>
      </div>

      {activeTab === "packages" ? (
        /* Token Packages */
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 sm:gap-6">
          {tokenPackages.map((pkg) => (
            <div
              key={pkg.id}
              className={`relative bg-white dark:bg-slate-900 rounded-2xl border-2 transition-all hover:shadow-xl hover:-translate-y-1 ${
                pkg.popular
                  ? "border-orange-500 shadow-lg shadow-orange-500/20"
                  : "border-violet-200 dark:border-violet-500/30 hover:border-orange-500/50"
              }`}
            >
              {pkg.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 text-white text-xs font-bold rounded-full shadow-lg">
                  🔥 MOST POPULAR
                </div>
              )}
              {pkg.discount && (
                <div className="absolute top-4 right-4 px-2 py-1 bg-gradient-to-r from-emerald-500 to-teal-500 text-white text-xs font-bold rounded-lg shadow-md">
                  {pkg.discount}
                </div>
              )}
              
              <div className="p-4 sm:p-6">
                <h3 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white mb-2">{pkg.name}</h3>
                <div className="flex items-baseline gap-1 mb-4">
                  <span className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-violet-600 to-fuchsia-600 bg-clip-text text-transparent">${pkg.price}</span>
                  <span className="text-slate-500 dark:text-slate-400">USD</span>
                </div>
                
                <div className="flex items-center gap-2 mb-6 p-3 bg-gradient-to-r from-violet-50 to-fuchsia-50 dark:from-violet-500/10 dark:to-fuchsia-500/10 rounded-xl border border-violet-200/50 dark:border-violet-500/20">
                  <svg className="w-5 h-5 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                  <span className="font-bold text-violet-700 dark:text-violet-300">{pkg.tokens.toLocaleString()} Credits</span>
                </div>

                <ul className="space-y-2 mb-6">
                  {pkg.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                      <svg className="w-4 h-4 text-emerald-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      {feature}
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => handleBuyTokens(pkg.id)}
                  className={`w-full py-3 rounded-xl font-semibold transition-all ${
                    pkg.popular
                      ? "bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 text-white hover:shadow-lg hover:shadow-orange-500/30"
                      : "bg-violet-100 dark:bg-violet-500/20 text-violet-700 dark:text-violet-300 hover:bg-violet-200 dark:hover:bg-violet-500/30"
                  }`}
                >
                  Buy Now
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Payment History Table */
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-violet-200 dark:border-violet-500/30 shadow-xl shadow-violet-200/50 dark:shadow-none overflow-hidden">
          <div className="p-4 sm:p-6 border-b border-violet-200 dark:border-violet-500/30 bg-gradient-to-r from-violet-50 to-fuchsia-50 dark:from-violet-500/10 dark:to-fuchsia-500/10">
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span>📋</span> Transaction History
            </h2>
            <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">View all your past payments</p>
          </div>
          
          {/* Desktop Table */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full">
              <thead className="bg-violet-50 dark:bg-violet-500/10">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-violet-600 dark:text-violet-400 uppercase tracking-wider">Transaction ID</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-violet-600 dark:text-violet-400 uppercase tracking-wider">Date</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-violet-600 dark:text-violet-400 uppercase tracking-wider">Package</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-violet-600 dark:text-violet-400 uppercase tracking-wider">Tokens</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-violet-600 dark:text-violet-400 uppercase tracking-wider">Amount</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-violet-600 dark:text-violet-400 uppercase tracking-wider">Method</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-violet-600 dark:text-violet-400 uppercase tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-violet-100 dark:divide-violet-500/20">
                {paymentHistory.map((payment) => (
                  <tr key={payment.id} className="hover:bg-violet-50 dark:hover:bg-violet-500/10 transition-colors">
                    <td className="px-6 py-4 text-sm font-mono text-slate-900 dark:text-white">{payment.id}</td>
                    <td className="px-6 py-4 text-sm text-slate-600 dark:text-slate-400">{payment.date}</td>
                    <td className="px-6 py-4 text-sm font-medium text-slate-900 dark:text-white">{payment.package}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1">
                        <svg className="w-4 h-4 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                        </svg>
                        <span className="text-sm font-medium text-slate-900 dark:text-white">{payment.tokens}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm font-semibold text-slate-900 dark:text-white">${payment.amount}</td>
                    <td className="px-6 py-4 text-sm text-slate-600 dark:text-slate-400">{payment.method}</td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex px-3 py-1 text-xs font-semibold rounded-full ${getStatusColor(payment.status)}`}>
                        {payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile Cards */}
          <div className="md:hidden divide-y divide-violet-100 dark:divide-violet-500/20">
            {paymentHistory.map((payment) => (
              <div key={payment.id} className="p-4 space-y-3 hover:bg-violet-50 dark:hover:bg-violet-500/10 transition-colors">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-slate-500 dark:text-slate-400">{payment.id}</span>
                  <span className={`inline-flex px-2 py-0.5 text-xs font-semibold rounded-full ${getStatusColor(payment.status)}`}>
                    {payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-slate-900 dark:text-white">{payment.package}</p>
                    <p className="text-sm text-slate-500 dark:text-slate-400">{payment.date}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-slate-900 dark:text-white">${payment.amount}</p>
                    <div className="flex items-center justify-end gap-1 text-sm text-orange-600 dark:text-orange-400">
                      <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                      </svg>
                      {payment.tokens}
                    </div>
                  </div>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">{payment.method}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Payment Modal */}
      {showPaymentModal && selectedPackage && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-md shadow-2xl border border-violet-200 dark:border-violet-500/30">
            <div className="p-6 border-b border-violet-200 dark:border-violet-500/30 bg-gradient-to-r from-violet-50 to-fuchsia-50 dark:from-violet-500/10 dark:to-fuchsia-500/10 rounded-t-2xl">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <span>💳</span> Complete Payment
                </h3>
                <button
                  onClick={() => setShowPaymentModal(false)}
                  className="p-2 hover:bg-violet-100 dark:hover:bg-violet-500/20 rounded-lg transition-colors"
                >
                  <svg className="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>

            <div className="p-6 space-y-4">
              {/* Selected Package Summary */}
              {(() => {
                const pkg = tokenPackages.find(p => p.id === selectedPackage);
                return pkg ? (
                  <div className="p-4 bg-gradient-to-r from-violet-50 to-fuchsia-50 dark:from-violet-500/10 dark:to-fuchsia-500/10 rounded-xl border border-violet-200/50 dark:border-violet-500/20">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold text-slate-900 dark:text-white">{pkg.name} Package</span>
                      <span className="font-bold text-violet-600 dark:text-violet-400">${pkg.price}</span>
                    </div>
                    <div className="flex items-center gap-1 text-sm text-orange-600 dark:text-orange-400">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                      </svg>
                      {pkg.tokens.toLocaleString()} Credits
                    </div>
                  </div>
                ) : null;
              })()}

              {/* Card Input */}
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  Card Number
                </label>
                <input
                  type="text"
                  placeholder="1234 5678 9012 3456"
                  className="w-full px-4 py-3 bg-violet-50 dark:bg-violet-500/10 border border-violet-200 dark:border-violet-500/30 rounded-xl focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 transition-all outline-none text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                    Expiry
                  </label>
                  <input
                    type="text"
                    placeholder="MM/YY"
                    className="w-full px-4 py-3 bg-violet-50 dark:bg-violet-500/10 border border-violet-200 dark:border-violet-500/30 rounded-xl focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 transition-all outline-none text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                    CVC
                  </label>
                  <input
                    type="text"
                    placeholder="123"
                    className="w-full px-4 py-3 bg-violet-50 dark:bg-violet-500/10 border border-violet-200 dark:border-violet-500/30 rounded-xl focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 transition-all outline-none text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              {/* Payment Methods */}
              <div className="flex items-center justify-center gap-4 py-3 border-t border-violet-200 dark:border-violet-500/30">
                <span className="text-xs text-slate-500">Secured by</span>
                <div className="flex items-center gap-2">
                  <div className="px-2 py-1 bg-blue-100 dark:bg-blue-500/20 rounded text-xs font-bold text-blue-700 dark:text-blue-300">VISA</div>
                  <div className="px-2 py-1 bg-red-100 dark:bg-red-500/20 rounded text-xs font-bold text-red-700 dark:text-red-300">Mastercard</div>
                  <div className="px-2 py-1 bg-indigo-100 dark:bg-indigo-500/20 rounded text-xs font-bold text-indigo-700 dark:text-indigo-300">PayPal</div>
                </div>
              </div>

              <button
                onClick={() => {
                  setShowPaymentModal(false);
                  alert("Payment successful! Tokens added to your account.");
                }}
                className="w-full py-4 bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all"
              >
                ✨ Pay Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
