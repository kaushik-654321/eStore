export default function PaymentsLoading() {
  return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <div className="flex flex-col items-center gap-4">
        {/* Card Icon with Spinner */}
        <div className="relative">
          <div className="w-20 h-20 bg-gradient-to-br from-emerald-500/20 to-teal-500/20 rounded-2xl flex items-center justify-center">
            <svg
              className="w-10 h-10 text-emerald-500"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"
              />
            </svg>
          </div>
          {/* Spinning border */}
          <div className="absolute -inset-1">
            <div className="w-full h-full border-4 border-transparent border-t-emerald-500 border-r-emerald-500 rounded-2xl animate-spin"></div>
          </div>
        </div>
        {/* Loading Text */}
        <p className="text-slate-600 dark:text-violet-300 font-medium">
          Loading Payment History...
        </p>
      </div>
    </div>
  );
}
