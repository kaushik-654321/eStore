"use client";

import { useState } from "react";

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  credits: number;
  icon: string;
}

const products: Product[] = [
  {
    id: "starter-pack",
    name: "Starter Pack",
    description: "100 AI Credits for basic usage",
    price: 9.99,
    credits: 100,
    icon: "🚀",
  },
  {
    id: "pro-pack",
    name: "Pro Pack",
    description: "500 AI Credits with priority processing",
    price: 39.99,
    credits: 500,
    icon: "⚡",
  },
  {
    id: "business-pack",
    name: "Business Pack",
    description: "1500 AI Credits with API access",
    price: 99.99,
    credits: 1500,
    icon: "💼",
  },
  {
    id: "enterprise-pack",
    name: "Enterprise Pack",
    description: "5000 AI Credits with dedicated support",
    price: 249.99,
    credits: 5000,
    icon: "🏢",
  },
  {
    id: "image-addon",
    name: "Image Generation Addon",
    description: "200 extra image generation credits",
    price: 19.99,
    credits: 200,
    icon: "🖼️",
  },
  {
    id: "audio-addon",
    name: "Audio Generation Addon",
    description: "150 extra audio generation credits",
    price: 24.99,
    credits: 150,
    icon: "🎵",
  },
  {
    id: "video-addon",
    name: "Video Generation Addon",
    description: "50 extra video generation credits",
    price: 49.99,
    credits: 50,
    icon: "🎬",
  },
];

type PaymentMethod = "card" | "upi";

export default function CheckoutPage() {
  const [selectedProduct, setSelectedProduct] = useState<string>("");
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("card");
  const [isProcessing, setIsProcessing] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  // Card details
  const [cardNumber, setCardNumber] = useState("");
  const [cardName, setCardName] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [cvv, setCvv] = useState("");
  const [saveCard, setSaveCard] = useState(false);

  // UPI details
  const [upiId, setUpiId] = useState("");

  const selectedProductData = products.find((p) => p.id === selectedProduct);

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || "";
    const parts = [];

    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }

    if (parts.length) {
      return parts.join(" ");
    } else {
      return value;
    }
  };

  const formatExpiryDate = (value: string) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
    if (v.length >= 2) {
      return v.substring(0, 2) + "/" + v.substring(2, 4);
    }
    return v;
  };

  const handlePayment = async () => {
    if (!selectedProduct) return;

    setIsProcessing(true);

    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 2500));

    setIsProcessing(false);
    alert(`Payment successful! ${selectedProductData?.credits} credits have been added to your account.`);
  };

  const getCardType = (number: string) => {
    const cleanNumber = number.replace(/\s/g, "");
    if (cleanNumber.startsWith("4")) return "visa";
    if (/^5[1-5]/.test(cleanNumber)) return "mastercard";
    if (/^3[47]/.test(cleanNumber)) return "amex";
    if (cleanNumber.startsWith("6")) return "discover";
    return null;
  };

  const cardType = getCardType(cardNumber);

  return (
    <div className="w-full space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br from-violet-500 via-fuchsia-500 to-orange-500 flex items-center justify-center shadow-lg shadow-violet-500/30">
              <svg className="w-5 h-5 sm:w-6 sm:h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
            </div>
            Checkout 💳
          </h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1">Select a product and complete your purchase</p>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 sm:gap-6">
        {/* Left Column - Product Selection & Payment Form */}
        <div className="xl:col-span-2 space-y-4 sm:space-y-6">
          {/* Product Selection */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-violet-100 dark:border-violet-500/20 shadow-xl shadow-violet-100/50 dark:shadow-none p-4 sm:p-6">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
              <span>📦</span> Select Product
            </h2>

            {/* Custom Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className="w-full flex items-center justify-between px-3 sm:px-4 py-3 sm:py-4 bg-violet-50 dark:bg-violet-500/10 border border-violet-200 dark:border-violet-500/30 rounded-xl focus:border-orange-400 focus:ring-2 focus:ring-orange-400/20 transition-all text-left"
              >
                {selectedProductData ? (
                  <div className="flex items-center gap-2 sm:gap-3 min-w-0">
                    <span className="text-xl sm:text-2xl flex-shrink-0">{selectedProductData.icon}</span>
                    <div className="min-w-0">
                      <p className="font-semibold text-slate-900 dark:text-white text-sm sm:text-base truncate">{selectedProductData.name}</p>
                      <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 truncate">{selectedProductData.description}</p>
                    </div>
                  </div>
                ) : (
                  <span className="text-slate-400 dark:text-violet-400/50 text-sm sm:text-base">Choose a product...</span>
                )}
                <svg
                  className={`w-5 h-5 text-violet-500 transition-transform flex-shrink-0 ${isDropdownOpen ? "rotate-180" : ""}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {/* Dropdown Menu */}
              {isDropdownOpen && (
                <div className="absolute z-20 w-full mt-2 bg-white dark:bg-slate-900 border border-violet-200 dark:border-violet-500/30 rounded-xl shadow-2xl shadow-violet-500/20 overflow-hidden">
                  <div className="max-h-64 sm:max-h-80 overflow-y-auto">
                    {products.map((product) => (
                      <button
                        key={product.id}
                        type="button"
                        onClick={() => {
                          setSelectedProduct(product.id);
                          setIsDropdownOpen(false);
                        }}
                        className={`w-full flex flex-col sm:flex-row sm:items-center justify-between px-3 sm:px-4 py-3 hover:bg-violet-50 dark:hover:bg-violet-500/10 transition-colors text-left gap-2 ${
                          selectedProduct === product.id ? "bg-violet-100 dark:bg-violet-500/20" : ""
                        }`}
                      >
                        <div className="flex items-center gap-2 sm:gap-3">
                          <span className="text-xl sm:text-2xl">{product.icon}</span>
                          <div>
                            <p className="font-semibold text-slate-900 dark:text-white text-sm sm:text-base">{product.name}</p>
                            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">{product.description}</p>
                          </div>
                        </div>
                        <div className="text-left sm:text-right ml-7 sm:ml-0">
                          <p className="font-bold text-violet-600 dark:text-violet-400">${product.price}</p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">{product.credits} credits</p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Payment Method Selection */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-violet-100 dark:border-violet-500/20 shadow-xl shadow-violet-100/50 dark:shadow-none p-4 sm:p-6">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
              <span>💰</span> Payment Method
            </h2>

            {/* Payment Method Tabs */}
            <div className="grid grid-cols-2 gap-2 sm:gap-3 mb-6">
              <button
                type="button"
                onClick={() => setPaymentMethod("card")}
                className={`flex items-center justify-center gap-2 sm:gap-3 p-3 sm:p-4 rounded-xl border-2 transition-all ${
                  paymentMethod === "card"
                    ? "border-orange-500 bg-orange-50 dark:bg-orange-500/10 shadow-lg shadow-orange-500/20"
                    : "border-slate-200 dark:border-slate-700 hover:border-violet-300 dark:hover:border-violet-500/50"
                }`}
              >
                <svg className="w-5 h-5 sm:w-6 sm:h-6 text-slate-700 dark:text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                </svg>
                <span className="font-medium text-slate-700 dark:text-slate-300 text-xs sm:text-sm">Credit / Debit Card</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod("upi")}
                className={`flex items-center justify-center gap-2 sm:gap-3 p-3 sm:p-4 rounded-xl border-2 transition-all ${
                  paymentMethod === "upi"
                    ? "border-orange-500 bg-orange-50 dark:bg-orange-500/10 shadow-lg shadow-orange-500/20"
                    : "border-slate-200 dark:border-slate-700 hover:border-violet-300 dark:hover:border-violet-500/50"
                }`}
              >
                <div className="w-5 h-5 sm:w-6 sm:h-6 bg-gradient-to-br from-green-500 to-emerald-600 rounded flex items-center justify-center text-white text-[10px] sm:text-xs font-bold">
                  UPI
                </div>
                <span className="font-medium text-slate-700 dark:text-slate-300 text-xs sm:text-sm">UPI Payment</span>
              </button>
            </div>

            {/* Card Payment Form */}
            {paymentMethod === "card" && (
              <div className="space-y-4">
                {/* Card Preview */}
                <div className="relative h-40 sm:h-48 bg-gradient-to-br from-violet-600 via-fuchsia-600 to-orange-500 rounded-2xl p-4 sm:p-6 text-white overflow-hidden shadow-xl shadow-violet-500/30">
                  <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iYSIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVHJhbnNmb3JtPSJyb3RhdGUoNDUpIj48cmVjdCB4PSIwIiB5PSIwIiB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIGZpbGw9InJnYmEoMjU1LDI1NSwyNTUsMC4wNSkiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IGZpbGw9InVybCgjYSkiIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiLz48L3N2Zz4=')] opacity-50"></div>
                  <div className="absolute top-0 right-0 w-24 sm:w-32 h-24 sm:h-32 bg-white/10 rounded-full blur-2xl -translate-y-1/2 translate-x-1/2"></div>
                  
                  <div className="relative">
                    {/* Chip */}
                    <div className="w-10 h-7 sm:w-12 sm:h-9 bg-gradient-to-br from-amber-300 to-amber-500 rounded-md mb-4 sm:mb-6 flex items-center justify-center">
                      <div className="w-6 h-5 sm:w-8 sm:h-6 border-2 border-amber-600/50 rounded-sm"></div>
                    </div>

                    {/* Card Number */}
                    <p className="text-base sm:text-xl font-mono tracking-wider mb-3 sm:mb-4">
                      {cardNumber || "•••• •••• •••• ••••"}
                    </p>

                    <div className="flex items-end justify-between">
                      <div>
                        <p className="text-[10px] sm:text-xs text-white/60 uppercase">Card Holder</p>
                        <p className="font-medium text-xs sm:text-base truncate max-w-[80px] sm:max-w-none">{cardName || "YOUR NAME"}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-[10px] sm:text-xs text-white/60 uppercase">Expires</p>
                        <p className="font-medium text-xs sm:text-base">{expiryDate || "MM/YY"}</p>
                      </div>
                      <div>
                        {cardType === "visa" && (
                          <div className="text-lg sm:text-2xl font-bold italic">VISA</div>
                        )}
                        {cardType === "mastercard" && (
                          <div className="flex">
                            <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-full bg-red-500 -mr-2 sm:-mr-3"></div>
                            <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-full bg-yellow-500"></div>
                          </div>
                        )}
                        {cardType === "amex" && (
                          <div className="text-sm sm:text-lg font-bold">AMEX</div>
                        )}
                        {!cardType && (
                          <div className="w-10 h-6 sm:w-12 sm:h-8 bg-white/20 rounded"></div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card Number */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                    Card Number
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                      maxLength={19}
                      placeholder="1234 5678 9012 3456"
                      className="w-full pl-10 sm:pl-12 pr-4 py-2.5 sm:py-3 bg-violet-50 dark:bg-violet-500/10 border border-violet-200 dark:border-violet-500/30 rounded-xl focus:border-orange-400 focus:ring-2 focus:ring-orange-400/20 transition-all outline-none text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-violet-400/50 font-mono text-sm sm:text-base"
                    />
                    <svg className="absolute left-3 sm:left-4 top-1/2 -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-violet-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                    </svg>
                  </div>
                </div>

                {/* Card Holder Name */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                    Card Holder Name
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={cardName}
                      onChange={(e) => setCardName(e.target.value.toUpperCase())}
                      placeholder="JOHN DOE"
                      className="w-full pl-10 sm:pl-12 pr-4 py-2.5 sm:py-3 bg-violet-50 dark:bg-violet-500/10 border border-violet-200 dark:border-violet-500/30 rounded-xl focus:border-orange-400 focus:ring-2 focus:ring-orange-400/20 transition-all outline-none text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-violet-400/50 uppercase text-sm sm:text-base"
                    />
                    <svg className="absolute left-3 sm:left-4 top-1/2 -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-violet-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                  </div>
                </div>

                {/* Expiry and CVV */}
                <div className="grid grid-cols-2 gap-3 sm:gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                      Expiry Date
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        value={expiryDate}
                        onChange={(e) => setExpiryDate(formatExpiryDate(e.target.value))}
                        maxLength={5}
                        placeholder="MM/YY"
                        className="w-full pl-10 sm:pl-12 pr-2 sm:pr-4 py-2.5 sm:py-3 bg-violet-50 dark:bg-violet-500/10 border border-violet-200 dark:border-violet-500/30 rounded-xl focus:border-orange-400 focus:ring-2 focus:ring-orange-400/20 transition-all outline-none text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-violet-400/50 font-mono text-sm sm:text-base"
                      />
                      <svg className="absolute left-3 sm:left-4 top-1/2 -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-violet-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                      </svg>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                      CVV
                    </label>
                    <div className="relative">
                      <input
                        type="password"
                        value={cvv}
                        onChange={(e) => setCvv(e.target.value.replace(/\D/g, "").slice(0, 4))}
                        maxLength={4}
                        placeholder="•••"
                        className="w-full pl-10 sm:pl-12 pr-2 sm:pr-4 py-2.5 sm:py-3 bg-violet-50 dark:bg-violet-500/10 border border-violet-200 dark:border-violet-500/30 rounded-xl focus:border-orange-400 focus:ring-2 focus:ring-orange-400/20 transition-all outline-none text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-violet-400/50 font-mono text-sm sm:text-base"
                      />
                      <svg className="absolute left-3 sm:left-4 top-1/2 -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-violet-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                      </svg>
                    </div>
                  </div>
                </div>

                {/* Save Card Checkbox */}
                <label className="flex items-center gap-2 sm:gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={saveCard}
                    onChange={(e) => setSaveCard(e.target.checked)}
                    className="w-4 h-4 sm:w-5 sm:h-5 rounded border-slate-300 text-orange-500 focus:ring-orange-500"
                  />
                  <span className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                    Save card for future payments
                  </span>
                </label>

                {/* Accepted Cards */}
                <div className="flex flex-wrap items-center gap-2 sm:gap-4 pt-2">
                  <span className="text-xs text-slate-500 dark:text-slate-400">We accept:</span>
                  <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
                    <div className="px-1.5 sm:px-2 py-0.5 sm:py-1 bg-blue-100 dark:bg-blue-500/20 rounded text-[10px] sm:text-xs font-bold text-blue-700 dark:text-blue-300">VISA</div>
                    <div className="px-1.5 sm:px-2 py-0.5 sm:py-1 bg-red-100 dark:bg-red-500/20 rounded text-[10px] sm:text-xs font-bold text-red-700 dark:text-red-300">Mastercard</div>
                    <div className="px-1.5 sm:px-2 py-0.5 sm:py-1 bg-blue-100 dark:bg-blue-500/20 rounded text-[10px] sm:text-xs font-bold text-blue-700 dark:text-blue-300">AMEX</div>
                    <div className="px-1.5 sm:px-2 py-0.5 sm:py-1 bg-orange-100 dark:bg-orange-500/20 rounded text-[10px] sm:text-xs font-bold text-orange-700 dark:text-orange-300">Discover</div>
                  </div>
                </div>
              </div>
            )}

            {/* UPI Payment Form */}
            {paymentMethod === "upi" && (
              <div className="space-y-4">
                {/* UPI Info Card */}
                <div className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl p-4 sm:p-6 text-white shadow-xl shadow-emerald-500/30">
                  <div className="flex items-center gap-3 sm:gap-4 mb-3 sm:mb-4">
                    <div className="w-12 h-12 sm:w-16 sm:h-16 bg-white rounded-xl sm:rounded-2xl flex items-center justify-center">
                      <span className="text-lg sm:text-2xl font-bold text-emerald-600">UPI</span>
                    </div>
                    <div>
                      <h3 className="text-lg sm:text-xl font-bold">UPI Payment</h3>
                      <p className="text-emerald-100 text-sm">Fast & Secure Transactions</p>
                    </div>
                  </div>
                  <p className="text-xs sm:text-sm text-emerald-100">
                    Pay directly from your bank account using any UPI app like Google Pay, PhonePe, Paytm, etc.
                  </p>
                </div>

                {/* UPI ID Input */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                    Enter UPI ID
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={upiId}
                      onChange={(e) => setUpiId(e.target.value)}
                      placeholder="yourname@upi"
                      className="w-full pl-10 sm:pl-12 pr-4 py-3 sm:py-4 bg-violet-50 dark:bg-violet-500/10 border border-violet-200 dark:border-violet-500/30 rounded-xl focus:border-orange-400 focus:ring-2 focus:ring-orange-400/20 transition-all outline-none text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-violet-400/50 text-sm sm:text-base"
                    />
                    <svg className="absolute left-3 sm:left-4 top-1/2 -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-violet-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.207" />
                    </svg>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
                    Example: username@okhdfcbank, username@ybl, username@paytm
                  </p>
                </div>

                {/* Popular UPI Apps */}
                <div>
                  <p className="text-sm font-medium text-slate-700 dark:text-slate-300 mb-3">
                    Or pay using
                  </p>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3">
                    {[
                      { name: "Google Pay", color: "from-blue-500 to-green-500", icon: "G" },
                      { name: "PhonePe", color: "from-purple-600 to-indigo-600", icon: "P" },
                      { name: "Paytm", color: "from-blue-500 to-cyan-500", icon: "₽" },
                      { name: "BHIM", color: "from-orange-500 to-red-500", icon: "B" },
                    ].map((app) => (
                      <button
                        key={app.name}
                        type="button"
                        className="flex flex-col items-center gap-1.5 sm:gap-2 p-3 sm:p-4 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-violet-300 dark:hover:border-violet-500/50 hover:bg-violet-50 dark:hover:bg-violet-500/10 transition-all"
                      >
                        <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br ${app.color} flex items-center justify-center text-white text-lg sm:text-xl font-bold shadow-lg`}>
                          {app.icon}
                        </div>
                        <span className="text-[10px] sm:text-xs text-slate-600 dark:text-slate-400">{app.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column - Order Summary */}
        <div className="xl:col-span-1">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-violet-100 dark:border-violet-500/20 shadow-xl shadow-violet-100/50 dark:shadow-none p-4 sm:p-6 sticky top-24">
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
              <span>🧾</span> Order Summary
            </h2>

            {selectedProductData ? (
              <div className="space-y-4">
                {/* Selected Product */}
                <div className="flex items-start gap-3 sm:gap-4 p-3 sm:p-4 bg-violet-50 dark:bg-violet-500/10 rounded-xl">
                  <span className="text-2xl sm:text-3xl">{selectedProductData.icon}</span>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-slate-900 dark:text-white text-sm sm:text-base truncate">{selectedProductData.name}</h3>
                    <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 line-clamp-2">{selectedProductData.description}</p>
                    <div className="flex items-center gap-1 mt-2 text-orange-600 dark:text-orange-400">
                      <svg className="w-3 h-3 sm:w-4 sm:h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                      </svg>
                      <span className="text-xs sm:text-sm font-medium">{selectedProductData.credits} Credits</span>
                    </div>
                  </div>
                </div>

                {/* Price Breakdown */}
                <div className="space-y-2 sm:space-y-3 pt-4 border-t border-slate-200 dark:border-slate-700">
                  <div className="flex items-center justify-between text-slate-600 dark:text-slate-400 text-sm">
                    <span>Subtotal</span>
                    <span>${selectedProductData.price.toFixed(2)}</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-600 dark:text-slate-400 text-sm">
                    <span>Tax (0%)</span>
                    <span>$0.00</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-600 dark:text-slate-400 text-sm">
                    <span>Processing Fee</span>
                    <span className="text-emerald-500">Free</span>
                  </div>
                </div>

                {/* Total */}
                <div className="flex items-center justify-between pt-4 border-t border-slate-200 dark:border-slate-700">
                  <span className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">Total</span>
                  <span className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-violet-600 to-fuchsia-600 bg-clip-text text-transparent">
                    ${selectedProductData.price.toFixed(2)}
                  </span>
                </div>

                {/* Pay Button */}
                <button
                  onClick={handlePayment}
                  disabled={isProcessing || (paymentMethod === "card" && (!cardNumber || !cardName || !expiryDate || !cvv)) || (paymentMethod === "upi" && !upiId)}
                  className="w-full py-3 sm:py-4 bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-sm sm:text-base"
                >
                  {isProcessing ? (
                    <>
                      <svg className="animate-spin w-4 h-4 sm:w-5 sm:h-5" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      <span>Processing...</span>
                    </>
                  ) : (
                    <>
                      <svg className="w-4 h-4 sm:w-5 sm:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                      </svg>
                      <span>Pay ${selectedProductData.price.toFixed(2)}</span>
                    </>
                  )}
                </button>

                {/* Security Note */}
                <div className="flex items-center justify-center gap-2 text-[10px] sm:text-xs text-slate-400 dark:text-slate-500">
                  <svg className="w-3 h-3 sm:w-4 sm:h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                  <span>Secured with 256-bit SSL encryption</span>
                </div>
              </div>
            ) : (
              <div className="text-center py-6 sm:py-8">
                <div className="w-12 h-12 sm:w-16 sm:h-16 mx-auto mb-3 sm:mb-4 rounded-xl sm:rounded-2xl bg-violet-100 dark:bg-violet-500/20 flex items-center justify-center">
                  <svg className="w-6 h-6 sm:w-8 sm:h-8 text-violet-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                  </svg>
                </div>
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  Select a product to see the summary
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
