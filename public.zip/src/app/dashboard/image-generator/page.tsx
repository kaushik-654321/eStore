"use client";

import Link from "next/link";

const categories = [
  {
    id: "photography",
    name: "Photography",
    emoji: "📷",
    description: "Realistic photos and portraits",
    color: "from-violet-500 to-purple-600",
    subcategories: 6,
    images: "12K+",
  },
  {
    id: "art",
    name: "Art & Illustration",
    emoji: "🎨",
    description: "Digital art, paintings, and illustrations",
    color: "from-fuchsia-500 to-pink-600",
    subcategories: 8,
    images: "15K+",
  },
  {
    id: "3d",
    name: "3D & Design",
    emoji: "🎲",
    description: "3D renders, models, and product designs",
    color: "from-amber-500 to-orange-600",
    subcategories: 5,
    images: "8K+",
  },
  {
    id: "anime",
    name: "Anime & Manga",
    emoji: "✨",
    description: "Anime characters and manga-style art",
    color: "from-rose-500 to-pink-600",
    subcategories: 7,
    images: "20K+",
  },
  {
    id: "nature",
    name: "Nature & Landscapes",
    emoji: "🌿",
    description: "Scenic views, wildlife, and nature",
    color: "from-emerald-500 to-teal-600",
    subcategories: 6,
    images: "10K+",
  },
  {
    id: "abstract",
    name: "Abstract & Patterns",
    emoji: "🔮",
    description: "Abstract art and geometric patterns",
    color: "from-indigo-500 to-blue-600",
    subcategories: 4,
    images: "6K+",
  },
  {
    id: "fantasy",
    name: "Fantasy & Sci-Fi",
    emoji: "🐉",
    description: "Fantasy worlds and sci-fi concepts",
    color: "from-purple-500 to-violet-600",
    subcategories: 9,
    images: "18K+",
  },
  {
    id: "architecture",
    name: "Architecture",
    emoji: "🏛️",
    description: "Buildings, interiors, and urban scenes",
    color: "from-slate-500 to-slate-700",
    subcategories: 5,
    images: "7K+",
  },
];

export default function ImageGeneratorPage() {
  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br from-violet-500 via-purple-500 to-fuchsia-500 flex items-center justify-center shadow-lg shadow-violet-500/30">
              <svg className="w-5 h-5 sm:w-6 sm:h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </div>
            Image Generator ✨
          </h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1 text-sm sm:text-base">
            Select a category to explore and generate images
          </p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-500/10 to-rose-500/10 dark:from-orange-500/20 dark:to-rose-500/20 rounded-xl border border-orange-500/20 w-fit">
          <svg className="w-5 h-5 text-orange-600 dark:text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
          <span className="font-medium text-orange-700 dark:text-orange-300">500 credits</span>
        </div>
      </div>

      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm">
        <Link href="/dashboard" className="text-slate-500 dark:text-slate-400 hover:text-violet-600 dark:hover:text-violet-400 transition-colors">
          Dashboard
        </Link>
        <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
        </svg>
        <span className="text-violet-600 dark:text-violet-400 font-medium">Image Generator</span>
      </nav>

      {/* Categories Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
        {categories.map((category) => (
          <Link
            key={category.id}
            href={`/dashboard/image-generator/${category.id}`}
            className="group bg-white dark:bg-slate-900 rounded-2xl border border-violet-100 dark:border-violet-500/20 shadow-lg shadow-violet-100/50 dark:shadow-none overflow-hidden hover:shadow-xl hover:shadow-violet-200/50 dark:hover:border-violet-500/40 transition-all duration-300 hover:-translate-y-1"
          >
            {/* Category Header */}
            <div className={`h-24 sm:h-28 bg-gradient-to-br ${category.color} relative overflow-hidden`}>
              <div className="absolute inset-0 bg-black/10"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-5xl sm:text-6xl opacity-80 group-hover:scale-125 transition-transform duration-300">
                  {category.emoji}
                </span>
              </div>
              {/* Decorative elements */}
              <div className="absolute top-2 right-2 w-16 h-16 bg-white/10 rounded-full blur-xl"></div>
              <div className="absolute bottom-2 left-2 w-12 h-12 bg-white/10 rounded-full blur-lg"></div>
            </div>

            {/* Category Content */}
            <div className="p-4 sm:p-5">
              <h3 className="font-bold text-slate-900 dark:text-white text-lg mb-1 group-hover:text-violet-600 dark:group-hover:text-violet-400 transition-colors">
                {category.name}
              </h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 mb-4 line-clamp-2">
                {category.description}
              </p>

              {/* Stats */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                    </svg>
                    <span>{category.subcategories} styles</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    <span>{category.images}</span>
                  </div>
                </div>
                <div className="w-8 h-8 rounded-full bg-violet-100 dark:bg-violet-500/20 flex items-center justify-center group-hover:bg-violet-500 transition-colors">
                  <svg className="w-4 h-4 text-violet-600 dark:text-violet-400 group-hover:text-white transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-violet-500/10 to-purple-500/10 dark:from-violet-500/20 dark:to-purple-500/20 rounded-2xl p-4 sm:p-5 border border-violet-200/50 dark:border-violet-500/20">
          <div className="text-2xl sm:text-3xl font-bold text-violet-600 dark:text-violet-400">8</div>
          <div className="text-sm text-slate-600 dark:text-slate-400">Categories</div>
        </div>
        <div className="bg-gradient-to-br from-fuchsia-500/10 to-pink-500/10 dark:from-fuchsia-500/20 dark:to-pink-500/20 rounded-2xl p-4 sm:p-5 border border-fuchsia-200/50 dark:border-fuchsia-500/20">
          <div className="text-2xl sm:text-3xl font-bold text-fuchsia-600 dark:text-fuchsia-400">50+</div>
          <div className="text-sm text-slate-600 dark:text-slate-400">Styles</div>
        </div>
        <div className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 dark:from-amber-500/20 dark:to-orange-500/20 rounded-2xl p-4 sm:p-5 border border-amber-200/50 dark:border-amber-500/20">
          <div className="text-2xl sm:text-3xl font-bold text-amber-600 dark:text-amber-400">96K+</div>
          <div className="text-sm text-slate-600 dark:text-slate-400">Images Created</div>
        </div>
        <div className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 dark:from-emerald-500/20 dark:to-teal-500/20 rounded-2xl p-4 sm:p-5 border border-emerald-200/50 dark:border-emerald-500/20">
          <div className="text-2xl sm:text-3xl font-bold text-emerald-600 dark:text-emerald-400">4.9★</div>
          <div className="text-sm text-slate-600 dark:text-slate-400">User Rating</div>
        </div>
      </div>
    </div>
  );
}
