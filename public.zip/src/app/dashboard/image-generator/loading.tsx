export default function ImageGeneratorLoading() {
  return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <div className="flex flex-col items-center gap-4">
        {/* Animated Icon */}
        <div className="relative">
          <div className="w-20 h-20 bg-gradient-to-br from-blue-500/20 to-indigo-500/20 rounded-2xl flex items-center justify-center">
            <svg
              className="w-10 h-10 text-blue-500 animate-pulse"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
              />
            </svg>
          </div>
          {/* Spinning ring */}
          <div className="absolute -inset-2">
            <div className="w-full h-full border-4 border-transparent border-t-blue-500 rounded-2xl animate-spin"></div>
          </div>
        </div>
        {/* Loading Text */}
        <p className="text-slate-600 dark:text-blue-300 font-medium">
          Loading Image Generator...
        </p>
      </div>
    </div>
  );
}
