"use client";

import Link from "next/link";
import { useParams, notFound } from "next/navigation";

const categoriesData: Record<string, {
  name: string;
  emoji: string;
  color: string;
  description: string;
  subcategories: {
    id: string;
    name: string;
    emoji: string;
    description: string;
    templates: number;
    popular: boolean;
  }[];
}> = {
  photography: {
    name: "Photography",
    emoji: "📷",
    color: "from-violet-500 to-purple-600",
    description: "Create stunning realistic photos and portraits",
    subcategories: [
      { id: "portrait", name: "Portrait Photography", emoji: "👤", description: "Professional headshots and portrait photos", templates: 25, popular: true },
      { id: "landscape", name: "Landscape Photography", emoji: "🏔️", description: "Beautiful scenic and nature photography", templates: 18, popular: true },
      { id: "product", name: "Product Photography", emoji: "📦", description: "E-commerce and product showcase photos", templates: 22, popular: false },
      { id: "food", name: "Food Photography", emoji: "🍕", description: "Appetizing food and beverage photos", templates: 15, popular: true },
      { id: "fashion", name: "Fashion Photography", emoji: "👗", description: "Stylish fashion and editorial photos", templates: 20, popular: false },
      { id: "street", name: "Street Photography", emoji: "🌆", description: "Urban and street life photography", templates: 12, popular: false },
    ],
  },
  art: {
    name: "Art & Illustration",
    emoji: "🎨",
    color: "from-fuchsia-500 to-pink-600",
    description: "Digital art, paintings, and creative illustrations",
    subcategories: [
      { id: "digital-art", name: "Digital Art", emoji: "🖼️", description: "Modern digital artwork and designs", templates: 30, popular: true },
      { id: "watercolor", name: "Watercolor", emoji: "💧", description: "Beautiful watercolor paintings", templates: 18, popular: true },
      { id: "oil-painting", name: "Oil Painting", emoji: "🎨", description: "Classic oil painting style", templates: 15, popular: false },
      { id: "sketch", name: "Pencil Sketch", emoji: "✏️", description: "Hand-drawn pencil sketches", templates: 20, popular: true },
      { id: "comic", name: "Comic Style", emoji: "💥", description: "Comic book and graphic novel style", templates: 25, popular: false },
      { id: "pop-art", name: "Pop Art", emoji: "🎯", description: "Bold and colorful pop art style", templates: 12, popular: false },
      { id: "minimalist", name: "Minimalist", emoji: "⬜", description: "Clean and simple minimalist art", templates: 16, popular: false },
      { id: "surreal", name: "Surrealism", emoji: "🌀", description: "Surreal and dreamlike imagery", templates: 14, popular: true },
    ],
  },
  "3d": {
    name: "3D & Design",
    emoji: "🎲",
    color: "from-amber-500 to-orange-600",
    description: "Professional 3D renders and product designs",
    subcategories: [
      { id: "product-render", name: "Product Renders", emoji: "📱", description: "High-quality product visualizations", templates: 28, popular: true },
      { id: "character", name: "3D Characters", emoji: "🧑", description: "Stylized 3D character designs", templates: 22, popular: true },
      { id: "environment", name: "3D Environments", emoji: "🌍", description: "Immersive 3D scenes and worlds", templates: 18, popular: false },
      { id: "isometric", name: "Isometric Design", emoji: "🔷", description: "Clean isometric illustrations", templates: 20, popular: true },
      { id: "low-poly", name: "Low Poly Art", emoji: "💎", description: "Geometric low poly style", templates: 15, popular: false },
    ],
  },
  anime: {
    name: "Anime & Manga",
    emoji: "✨",
    color: "from-rose-500 to-pink-600",
    description: "Japanese anime and manga style artwork",
    subcategories: [
      { id: "anime-portrait", name: "Anime Portraits", emoji: "👧", description: "Beautiful anime character portraits", templates: 35, popular: true },
      { id: "manga", name: "Manga Style", emoji: "📖", description: "Black and white manga artwork", templates: 25, popular: true },
      { id: "chibi", name: "Chibi Characters", emoji: "🎀", description: "Cute chibi character designs", templates: 20, popular: true },
      { id: "mecha", name: "Mecha & Robots", emoji: "🤖", description: "Giant robots and mecha designs", templates: 18, popular: false },
      { id: "anime-landscape", name: "Anime Scenery", emoji: "🌸", description: "Beautiful anime backgrounds", templates: 22, popular: false },
      { id: "vtuber", name: "VTuber Style", emoji: "🎭", description: "Virtual YouTuber character designs", templates: 15, popular: true },
      { id: "pixel-anime", name: "Pixel Anime", emoji: "👾", description: "Retro pixel art anime style", templates: 12, popular: false },
    ],
  },
  nature: {
    name: "Nature & Landscapes",
    emoji: "🌿",
    color: "from-emerald-500 to-teal-600",
    description: "Beautiful natural scenery and wildlife",
    subcategories: [
      { id: "mountains", name: "Mountains", emoji: "⛰️", description: "Majestic mountain landscapes", templates: 18, popular: true },
      { id: "ocean", name: "Ocean & Beach", emoji: "🌊", description: "Serene ocean and coastal scenes", templates: 20, popular: true },
      { id: "forest", name: "Forests", emoji: "🌲", description: "Lush forest and woodland imagery", templates: 16, popular: false },
      { id: "wildlife", name: "Wildlife", emoji: "🦁", description: "Wild animals in natural habitats", templates: 22, popular: true },
      { id: "seasons", name: "Seasonal Scenes", emoji: "🍂", description: "Beautiful seasonal landscapes", templates: 15, popular: false },
      { id: "macro", name: "Macro Nature", emoji: "🐝", description: "Close-up nature photography", templates: 12, popular: false },
    ],
  },
  abstract: {
    name: "Abstract & Patterns",
    emoji: "🔮",
    color: "from-indigo-500 to-blue-600",
    description: "Creative abstract art and geometric patterns",
    subcategories: [
      { id: "geometric", name: "Geometric Patterns", emoji: "🔷", description: "Clean geometric designs", templates: 25, popular: true },
      { id: "fluid", name: "Fluid Art", emoji: "🌈", description: "Flowing liquid and marble effects", templates: 20, popular: true },
      { id: "fractal", name: "Fractals", emoji: "🌀", description: "Mathematical fractal patterns", templates: 15, popular: false },
      { id: "gradient", name: "Gradients", emoji: "🎨", description: "Beautiful color gradients", templates: 18, popular: true },
    ],
  },
  fantasy: {
    name: "Fantasy & Sci-Fi",
    emoji: "🐉",
    color: "from-purple-500 to-violet-600",
    description: "Magical fantasy worlds and futuristic sci-fi",
    subcategories: [
      { id: "dragons", name: "Dragons & Creatures", emoji: "🐲", description: "Mythical creatures and beasts", templates: 28, popular: true },
      { id: "magic", name: "Magic & Spells", emoji: "🪄", description: "Magical effects and wizardry", templates: 22, popular: true },
      { id: "medieval", name: "Medieval Fantasy", emoji: "🏰", description: "Castles, knights, and kingdoms", templates: 25, popular: false },
      { id: "cyberpunk", name: "Cyberpunk", emoji: "🌃", description: "Neon-lit cyberpunk cityscapes", templates: 30, popular: true },
      { id: "space", name: "Space & Planets", emoji: "🚀", description: "Galaxies, planets, and spaceships", templates: 24, popular: true },
      { id: "steampunk", name: "Steampunk", emoji: "⚙️", description: "Victorian-era steampunk aesthetic", templates: 18, popular: false },
      { id: "underwater", name: "Underwater Worlds", emoji: "🧜", description: "Deep sea and underwater fantasy", templates: 15, popular: false },
      { id: "apocalyptic", name: "Post-Apocalyptic", emoji: "☢️", description: "Dystopian wasteland scenes", templates: 20, popular: false },
      { id: "ethereal", name: "Ethereal & Dreamlike", emoji: "✨", description: "Mystical and dreamlike imagery", templates: 22, popular: true },
    ],
  },
  architecture: {
    name: "Architecture",
    emoji: "🏛️",
    color: "from-slate-500 to-slate-700",
    description: "Buildings, interiors, and urban landscapes",
    subcategories: [
      { id: "modern", name: "Modern Architecture", emoji: "🏢", description: "Contemporary building designs", templates: 22, popular: true },
      { id: "interior", name: "Interior Design", emoji: "🛋️", description: "Beautiful room and space designs", templates: 28, popular: true },
      { id: "classical", name: "Classical Architecture", emoji: "🏛️", description: "Historic and classical buildings", templates: 15, popular: false },
      { id: "futuristic", name: "Futuristic Buildings", emoji: "🌆", description: "Sci-fi inspired architecture", templates: 20, popular: true },
      { id: "urban", name: "Urban Landscapes", emoji: "🌃", description: "City skylines and streetscapes", templates: 18, popular: false },
    ],
  },
};

export default function SubcategoryPage() {
  const params = useParams();
  const categoryId = params.category as string;
  
  const category = categoriesData[categoryId];
  
  if (!category) {
    notFound();
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
            <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br ${category.color} flex items-center justify-center shadow-lg`}>
              <span className="text-2xl">{category.emoji}</span>
            </div>
            {category.name}
          </h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1 text-sm sm:text-base">
            {category.description}
          </p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-500/10 to-rose-500/10 dark:from-orange-500/20 dark:to-rose-500/20 rounded-xl border border-orange-500/20 w-fit">
          <svg className="w-5 h-5 text-orange-600 dark:text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
          <span className="font-medium text-orange-700 dark:text-orange-300">500 credits</span>
        </div>
      </div>

      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm flex-wrap">
        <Link href="/dashboard" className="text-slate-500 dark:text-slate-400 hover:text-violet-600 dark:hover:text-violet-400 transition-colors">
          Dashboard
        </Link>
        <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
        </svg>
        <Link href="/dashboard/image-generator" className="text-slate-500 dark:text-slate-400 hover:text-violet-600 dark:hover:text-violet-400 transition-colors">
          Image Generator
        </Link>
        <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
        </svg>
        <span className="text-violet-600 dark:text-violet-400 font-medium">{category.name}</span>
      </nav>

      {/* Popular Styles Section */}
      {category.subcategories.some(s => s.popular) && (
        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white flex items-center gap-2">
            <span className="text-xl">🔥</span> Popular Styles
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {category.subcategories.filter(s => s.popular).map((subcategory) => (
              <Link
                key={subcategory.id}
                href={`/dashboard/image-generator/${categoryId}/${subcategory.id}`}
                className="group bg-gradient-to-br from-violet-500/5 to-fuchsia-500/5 dark:from-violet-500/10 dark:to-fuchsia-500/10 rounded-2xl border border-violet-200 dark:border-violet-500/30 p-4 sm:p-5 hover:shadow-xl hover:shadow-violet-200/50 dark:hover:border-violet-500/50 transition-all duration-300 hover:-translate-y-1"
              >
                <div className="flex items-start gap-4">
                  <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${category.color} flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform`}>
                    <span className="text-2xl">{subcategory.emoji}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-slate-900 dark:text-white group-hover:text-violet-600 dark:group-hover:text-violet-400 transition-colors truncate">
                        {subcategory.name}
                      </h3>
                      <span className="px-2 py-0.5 bg-amber-500/20 text-amber-700 dark:text-amber-400 text-xs font-medium rounded-full">
                        Popular
                      </span>
                    </div>
                    <p className="text-sm text-slate-500 dark:text-slate-400 line-clamp-2 mb-2">
                      {subcategory.description}
                    </p>
                    <div className="flex items-center gap-1 text-xs text-violet-600 dark:text-violet-400">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                      </svg>
                      <span>{subcategory.templates} templates</span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* All Styles Section */}
      <div className="space-y-4">
        <h2 className="text-lg font-semibold text-slate-900 dark:text-white flex items-center gap-2">
          <span className="text-xl">📁</span> All Styles
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {category.subcategories.map((subcategory) => (
            <Link
              key={subcategory.id}
              href={`/dashboard/image-generator/${categoryId}/${subcategory.id}`}
              className="group bg-white dark:bg-slate-900 rounded-2xl border border-violet-100 dark:border-violet-500/20 shadow-lg shadow-violet-100/50 dark:shadow-none overflow-hidden hover:shadow-xl hover:shadow-violet-200/50 dark:hover:border-violet-500/40 transition-all duration-300 hover:-translate-y-1"
            >
              {/* Subcategory Header */}
              <div className={`h-20 bg-gradient-to-br ${category.color} relative overflow-hidden`}>
                <div className="absolute inset-0 bg-black/10"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-4xl opacity-80 group-hover:scale-125 transition-transform duration-300">
                    {subcategory.emoji}
                  </span>
                </div>
                {subcategory.popular && (
                  <div className="absolute top-2 right-2 px-2 py-0.5 bg-amber-500 text-white text-xs font-medium rounded-full shadow-lg">
                    🔥 Popular
                  </div>
                )}
              </div>

              {/* Subcategory Content */}
              <div className="p-4">
                <h3 className="font-bold text-slate-900 dark:text-white text-base mb-1 group-hover:text-violet-600 dark:group-hover:text-violet-400 transition-colors truncate">
                  {subcategory.name}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mb-3 line-clamp-2">
                  {subcategory.description}
                </p>

                {/* Stats */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    <span>{subcategory.templates} templates</span>
                  </div>
                  <div className="w-7 h-7 rounded-full bg-violet-100 dark:bg-violet-500/20 flex items-center justify-center group-hover:bg-violet-500 transition-colors">
                    <svg className="w-3.5 h-3.5 text-violet-600 dark:text-violet-400 group-hover:text-white transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Back Button */}
      <div className="pt-4">
        <Link
          href="/dashboard/image-generator"
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-600 dark:text-slate-400 hover:text-violet-600 dark:hover:text-violet-400 transition-colors"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          Back to Categories
        </Link>
      </div>
    </div>
  );
}
