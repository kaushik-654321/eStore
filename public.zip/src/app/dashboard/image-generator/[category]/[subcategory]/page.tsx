"use client";

import { useState, useRef } from "react";
import Link from "next/link";
import { useParams, notFound } from "next/navigation";

const categoriesData: Record<string, {
  name: string;
  emoji: string;
  color: string;
  subcategories: Record<string, {
    name: string;
    emoji: string;
    description: string;
  }>;
}> = {
  photography: {
    name: "Photography",
    emoji: "📷",
    color: "from-violet-500 to-purple-600",
    subcategories: {
      portrait: { name: "Portrait Photography", emoji: "👤", description: "Professional headshots and portrait photos" },
      landscape: { name: "Landscape Photography", emoji: "🏔️", description: "Beautiful scenic and nature photography" },
      product: { name: "Product Photography", emoji: "📦", description: "E-commerce and product showcase photos" },
      food: { name: "Food Photography", emoji: "🍕", description: "Appetizing food and beverage photos" },
      fashion: { name: "Fashion Photography", emoji: "👗", description: "Stylish fashion and editorial photos" },
      street: { name: "Street Photography", emoji: "🌆", description: "Urban and street life photography" },
    },
  },
  art: {
    name: "Art & Illustration",
    emoji: "🎨",
    color: "from-fuchsia-500 to-pink-600",
    subcategories: {
      "digital-art": { name: "Digital Art", emoji: "🖼️", description: "Modern digital artwork and designs" },
      watercolor: { name: "Watercolor", emoji: "💧", description: "Beautiful watercolor paintings" },
      "oil-painting": { name: "Oil Painting", emoji: "🎨", description: "Classic oil painting style" },
      sketch: { name: "Pencil Sketch", emoji: "✏️", description: "Hand-drawn pencil sketches" },
      comic: { name: "Comic Style", emoji: "💥", description: "Comic book and graphic novel style" },
      "pop-art": { name: "Pop Art", emoji: "🎯", description: "Bold and colorful pop art style" },
      minimalist: { name: "Minimalist", emoji: "⬜", description: "Clean and simple minimalist art" },
      surreal: { name: "Surrealism", emoji: "🌀", description: "Surreal and dreamlike imagery" },
    },
  },
  "3d": {
    name: "3D & Design",
    emoji: "🎲",
    color: "from-amber-500 to-orange-600",
    subcategories: {
      "product-render": { name: "Product Renders", emoji: "📱", description: "High-quality product visualizations" },
      character: { name: "3D Characters", emoji: "🧑", description: "Stylized 3D character designs" },
      environment: { name: "3D Environments", emoji: "🌍", description: "Immersive 3D scenes and worlds" },
      isometric: { name: "Isometric Design", emoji: "🔷", description: "Clean isometric illustrations" },
      "low-poly": { name: "Low Poly Art", emoji: "💎", description: "Geometric low poly style" },
    },
  },
  anime: {
    name: "Anime & Manga",
    emoji: "✨",
    color: "from-rose-500 to-pink-600",
    subcategories: {
      "anime-portrait": { name: "Anime Portraits", emoji: "👧", description: "Beautiful anime character portraits" },
      manga: { name: "Manga Style", emoji: "📖", description: "Black and white manga artwork" },
      chibi: { name: "Chibi Characters", emoji: "🎀", description: "Cute chibi character designs" },
      mecha: { name: "Mecha & Robots", emoji: "🤖", description: "Giant robots and mecha designs" },
      "anime-landscape": { name: "Anime Scenery", emoji: "🌸", description: "Beautiful anime backgrounds" },
      vtuber: { name: "VTuber Style", emoji: "🎭", description: "Virtual YouTuber character designs" },
      "pixel-anime": { name: "Pixel Anime", emoji: "👾", description: "Retro pixel art anime style" },
    },
  },
  nature: {
    name: "Nature & Landscapes",
    emoji: "🌿",
    color: "from-emerald-500 to-teal-600",
    subcategories: {
      mountains: { name: "Mountains", emoji: "⛰️", description: "Majestic mountain landscapes" },
      ocean: { name: "Ocean & Beach", emoji: "🌊", description: "Serene ocean and coastal scenes" },
      forest: { name: "Forests", emoji: "🌲", description: "Lush forest and woodland imagery" },
      wildlife: { name: "Wildlife", emoji: "🦁", description: "Wild animals in natural habitats" },
      seasons: { name: "Seasonal Scenes", emoji: "🍂", description: "Beautiful seasonal landscapes" },
      macro: { name: "Macro Nature", emoji: "🐝", description: "Close-up nature photography" },
    },
  },
  abstract: {
    name: "Abstract & Patterns",
    emoji: "🔮",
    color: "from-indigo-500 to-blue-600",
    subcategories: {
      geometric: { name: "Geometric Patterns", emoji: "🔷", description: "Clean geometric designs" },
      fluid: { name: "Fluid Art", emoji: "🌈", description: "Flowing liquid and marble effects" },
      fractal: { name: "Fractals", emoji: "🌀", description: "Mathematical fractal patterns" },
      gradient: { name: "Gradients", emoji: "🎨", description: "Beautiful color gradients" },
    },
  },
  fantasy: {
    name: "Fantasy & Sci-Fi",
    emoji: "🐉",
    color: "from-purple-500 to-violet-600",
    subcategories: {
      dragons: { name: "Dragons & Creatures", emoji: "🐲", description: "Mythical creatures and beasts" },
      magic: { name: "Magic & Spells", emoji: "🪄", description: "Magical effects and wizardry" },
      medieval: { name: "Medieval Fantasy", emoji: "🏰", description: "Castles, knights, and kingdoms" },
      cyberpunk: { name: "Cyberpunk", emoji: "🌃", description: "Neon-lit cyberpunk cityscapes" },
      space: { name: "Space & Planets", emoji: "🚀", description: "Galaxies, planets, and spaceships" },
      steampunk: { name: "Steampunk", emoji: "⚙️", description: "Victorian-era steampunk aesthetic" },
      underwater: { name: "Underwater Worlds", emoji: "🧜", description: "Deep sea and underwater fantasy" },
      apocalyptic: { name: "Post-Apocalyptic", emoji: "☢️", description: "Dystopian wasteland scenes" },
      ethereal: { name: "Ethereal & Dreamlike", emoji: "✨", description: "Mystical and dreamlike imagery" },
    },
  },
  architecture: {
    name: "Architecture",
    emoji: "🏛️",
    color: "from-slate-500 to-slate-700",
    subcategories: {
      modern: { name: "Modern Architecture", emoji: "🏢", description: "Contemporary building designs" },
      interior: { name: "Interior Design", emoji: "🛋️", description: "Beautiful room and space designs" },
      classical: { name: "Classical Architecture", emoji: "🏛️", description: "Historic and classical buildings" },
      futuristic: { name: "Futuristic Buildings", emoji: "🌆", description: "Sci-fi inspired architecture" },
      urban: { name: "Urban Landscapes", emoji: "🌃", description: "City skylines and streetscapes" },
    },
  },
};

const sizeOptions = [
  { id: "square", name: "Square", size: "1024×1024", icon: "⬜" },
  { id: "portrait", name: "Portrait", size: "768×1024", icon: "📱" },
  { id: "landscape", name: "Landscape", size: "1024×768", icon: "🖼️" },
  { id: "wide", name: "Wide", size: "1920×1080", icon: "📺" },
];

const qualityOptions = [
  { id: "standard", name: "Standard", credits: 5 },
  { id: "hd", name: "HD", credits: 10 },
  { id: "ultra", name: "Ultra HD", credits: 20 },
];

export default function GeneratePage() {
  const params = useParams();
  const categoryId = params.category as string;
  const subcategoryId = params.subcategory as string;
  
  const category = categoriesData[categoryId];
  const subcategory = category?.subcategories[subcategoryId];
  
  if (!category || !subcategory) {
    notFound();
  }

  const [prompt, setPrompt] = useState("");
  const [selectedSize, setSelectedSize] = useState("square");
  const [selectedQuality, setSelectedQuality] = useState("standard");
  const [imageCount, setImageCount] = useState(1);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImages, setGeneratedImages] = useState<string[]>([]);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"prompt" | "upload">("prompt");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const selectedQualityData = qualityOptions.find(q => q.id === selectedQuality);
  const totalCredits = (selectedQualityData?.credits || 5) * imageCount;

  const handleGenerate = async () => {
    if (!prompt.trim() && !uploadedImage) return;
    
    setIsGenerating(true);
    await new Promise((resolve) => setTimeout(resolve, 2500));
    
    const colors = ["6366f1", "8b5cf6", "d946ef", "ec4899", "f97316", "14b8a6"];
    setGeneratedImages(
      Array.from({ length: imageCount }, (_, i) => 
        `https://placehold.co/512x512/${colors[i % colors.length]}/ffffff?text=${subcategory.name.replace(/\s/g, "+")}+${i + 1}`
      )
    );
    
    setIsGenerating(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setUploadedImage(url);
    }
  };

  const removeUploadedImage = () => {
    if (uploadedImage) {
      URL.revokeObjectURL(uploadedImage);
      setUploadedImage(null);
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
            <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br ${category.color} flex items-center justify-center shadow-lg`}>
              <span className="text-2xl">{subcategory.emoji}</span>
            </div>
            {subcategory.name}
          </h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1 text-sm sm:text-base">
            {subcategory.description}
          </p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-500/10 to-rose-500/10 dark:from-orange-500/20 dark:to-rose-500/20 rounded-xl border border-orange-500/20 w-fit">
          <svg className="w-5 h-5 text-orange-600 dark:text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
          <span className="font-medium text-orange-700 dark:text-orange-300">{totalCredits} credits</span>
        </div>
      </div>

      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm flex-wrap">
        <Link href="/dashboard" className="text-slate-500 dark:text-slate-400 hover:text-violet-600 dark:hover:text-violet-400 transition-colors">
          Dashboard
        </Link>
        <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
        </svg>
        <Link href="/dashboard/image-generator" className="text-slate-500 dark:text-slate-400 hover:text-violet-600 dark:hover:text-violet-400 transition-colors">
          Image Generator
        </Link>
        <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
        </svg>
        <Link href={`/dashboard/image-generator/${categoryId}`} className="text-slate-500 dark:text-slate-400 hover:text-violet-600 dark:hover:text-violet-400 transition-colors">
          {category.name}
        </Link>
        <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
        </svg>
        <span className="text-violet-600 dark:text-violet-400 font-medium">{subcategory.name}</span>
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 sm:gap-6">
        {/* Left Panel - Input */}
        <div className="lg:col-span-2 space-y-4 sm:space-y-6">
          {/* Input Tabs */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-violet-200 dark:border-violet-500/30 shadow-xl shadow-violet-200/50 dark:shadow-none overflow-hidden">
            <div className="flex border-b border-violet-200 dark:border-violet-500/30">
              <button
                onClick={() => setActiveTab("prompt")}
                className={`flex-1 px-3 sm:px-6 py-3 sm:py-4 text-xs sm:text-sm font-medium transition-all ${
                  activeTab === "prompt"
                    ? "bg-gradient-to-r from-violet-500/10 to-fuchsia-500/10 text-violet-700 dark:text-violet-300 border-b-2 border-violet-500"
                    : "text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
                }`}
              >
                ✍️ Text Prompt
              </button>
              <button
                onClick={() => setActiveTab("upload")}
                className={`flex-1 px-3 sm:px-6 py-3 sm:py-4 text-xs sm:text-sm font-medium transition-all ${
                  activeTab === "upload"
                    ? "bg-gradient-to-r from-violet-500/10 to-fuchsia-500/10 text-violet-700 dark:text-violet-300 border-b-2 border-violet-500"
                    : "text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
                }`}
              >
                📤 Upload Image
              </button>
            </div>

            <div className="p-4 sm:p-6">
              {activeTab === "prompt" ? (
                <div className="space-y-4">
                  <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder={`Describe your ${subcategory.name.toLowerCase()} image...`}
                    className="w-full h-32 p-4 bg-violet-50 dark:bg-violet-500/10 border border-violet-200 dark:border-violet-500/30 rounded-xl focus:border-orange-400 focus:ring-2 focus:ring-orange-400/20 transition-all outline-none text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-violet-400/50 resize-none text-sm sm:text-base"
                  />
                  <div className="flex flex-wrap gap-2">
                    <span className="text-xs text-slate-500 dark:text-slate-400">Suggestions:</span>
                    {["detailed", "cinematic", "vibrant colors", "high quality"].map((tag) => (
                      <button
                        key={tag}
                        onClick={() => setPrompt((prev) => prev + (prev ? ", " : "") + tag)}
                        className="px-2 py-1 text-xs bg-violet-100 dark:bg-violet-500/20 text-violet-700 dark:text-violet-300 rounded-lg hover:bg-violet-200 dark:hover:bg-violet-500/30 transition-colors"
                      >
                        + {tag}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {uploadedImage ? (
                    <div className="relative">
                      <img
                        src={uploadedImage}
                        alt="Uploaded"
                        className="w-full h-48 object-cover rounded-xl"
                      />
                      <button
                        onClick={removeUploadedImage}
                        className="absolute top-2 right-2 w-8 h-8 bg-red-500 text-white rounded-full flex items-center justify-center hover:bg-red-600 transition-colors"
                      >
                        ×
                      </button>
                    </div>
                  ) : (
                    <label className="flex flex-col items-center justify-center h-48 border-2 border-dashed border-violet-300 dark:border-violet-500/50 rounded-xl cursor-pointer hover:border-violet-400 dark:hover:border-violet-500 transition-colors bg-violet-50/50 dark:bg-violet-500/5">
                      <svg className="w-12 h-12 text-violet-400 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                      </svg>
                      <span className="text-sm text-slate-500 dark:text-slate-400">Click to upload an image</span>
                      <span className="text-xs text-slate-400 dark:text-slate-500 mt-1">PNG, JPG up to 10MB</span>
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </label>
                  )}
                  <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Describe how you want to transform this image..."
                    className="w-full h-20 p-4 bg-violet-50 dark:bg-violet-500/10 border border-violet-200 dark:border-violet-500/30 rounded-xl focus:border-orange-400 focus:ring-2 focus:ring-orange-400/20 transition-all outline-none text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-violet-400/50 resize-none text-sm"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Size Options */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-violet-200 dark:border-violet-500/30 shadow-xl shadow-violet-200/50 dark:shadow-none p-4 sm:p-6">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
              <span>📐</span> Image Size
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3">
              {sizeOptions.map((size) => (
                <button
                  key={size.id}
                  onClick={() => setSelectedSize(size.id)}
                  className={`p-3 rounded-xl border-2 transition-all text-center ${
                    selectedSize === size.id
                      ? "border-violet-500 bg-violet-50 dark:bg-violet-500/20"
                      : "border-slate-200 dark:border-slate-700 hover:border-violet-300"
                  }`}
                >
                  <span className="text-xl block mb-1">{size.icon}</span>
                  <span className="text-xs font-medium text-slate-900 dark:text-white block">{size.name}</span>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400">{size.size}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Quality Options */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-violet-200 dark:border-violet-500/30 shadow-xl shadow-violet-200/50 dark:shadow-none p-4 sm:p-6">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
              <span>✨</span> Quality
            </h3>
            <div className="grid grid-cols-3 gap-2 sm:gap-3">
              {qualityOptions.map((quality) => (
                <button
                  key={quality.id}
                  onClick={() => setSelectedQuality(quality.id)}
                  className={`p-3 rounded-xl border-2 transition-all text-center ${
                    selectedQuality === quality.id
                      ? "border-violet-500 bg-violet-50 dark:bg-violet-500/20"
                      : "border-slate-200 dark:border-slate-700 hover:border-violet-300"
                  }`}
                >
                  <span className="text-xs sm:text-sm font-medium text-slate-900 dark:text-white block">{quality.name}</span>
                  <span className="text-[10px] sm:text-xs text-orange-600 dark:text-orange-400">{quality.credits} credits</span>
                </button>
              ))}
            </div>
          </div>

          {/* Image Count */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-violet-200 dark:border-violet-500/30 shadow-xl shadow-violet-200/50 dark:shadow-none p-4 sm:p-6">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
              <span>🖼️</span> Number of Images
            </h3>
            <div className="flex items-center gap-4">
              <input
                type="range"
                min="1"
                max="4"
                value={imageCount}
                onChange={(e) => setImageCount(Number(e.target.value))}
                className="flex-1 accent-violet-500"
              />
              <span className="w-8 h-8 flex items-center justify-center bg-violet-100 dark:bg-violet-500/20 rounded-lg text-violet-700 dark:text-violet-300 font-bold text-sm">
                {imageCount}
              </span>
            </div>
          </div>

          {/* Generate Button */}
          <button
            onClick={handleGenerate}
            disabled={isGenerating || (!prompt.trim() && !uploadedImage)}
            className="w-full py-4 bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-orange-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-sm sm:text-base"
          >
            {isGenerating ? (
              <>
                <svg className="animate-spin w-5 h-5" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <span>Generating...</span>
              </>
            ) : (
              <>
                <span>✨</span>
                <span>Generate {imageCount} Image{imageCount > 1 ? "s" : ""}</span>
                <span className="px-2 py-0.5 bg-white/20 rounded-lg text-xs">{totalCredits} credits</span>
              </>
            )}
          </button>
        </div>

        {/* Right Panel - Results */}
        <div className="lg:col-span-3">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-violet-200 dark:border-violet-500/30 shadow-xl shadow-violet-200/50 dark:shadow-none p-4 sm:p-6 min-h-[400px]">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
              <span>🎨</span> Generated Images
            </h3>

            {generatedImages.length > 0 ? (
              <div className="grid grid-cols-2 gap-4">
                {generatedImages.map((image, index) => (
                  <div
                    key={index}
                    className="relative group rounded-xl overflow-hidden border border-violet-200 dark:border-violet-500/30"
                  >
                    <img
                      src={image}
                      alt={`Generated ${index + 1}`}
                      className="w-full aspect-square object-cover"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/50 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
                      <div className="flex gap-2">
                        <button className="w-10 h-10 bg-white rounded-full flex items-center justify-center hover:bg-violet-100 transition-colors">
                          <svg className="w-5 h-5 text-slate-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                          </svg>
                        </button>
                        <button className="w-10 h-10 bg-white rounded-full flex items-center justify-center hover:bg-violet-100 transition-colors">
                          <svg className="w-5 h-5 text-slate-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
                          </svg>
                        </button>
                        <button className="w-10 h-10 bg-white rounded-full flex items-center justify-center hover:bg-violet-100 transition-colors">
                          <svg className="w-5 h-5 text-slate-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                          </svg>
                        </button>
                      </div>
                    </div>
                    <div className="absolute top-2 left-2 px-2 py-1 bg-black/50 text-white text-xs rounded-lg">
                      #{index + 1}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-80 text-center">
                <div className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${category.color} flex items-center justify-center mb-4 opacity-50`}>
                  <span className="text-4xl">{subcategory.emoji}</span>
                </div>
                <h4 className="text-slate-900 dark:text-white font-medium mb-2">No images yet</h4>
                <p className="text-sm text-slate-500 dark:text-slate-400 max-w-xs">
                  Enter a prompt and click generate to create your {subcategory.name.toLowerCase()} images
                </p>
              </div>
            )}
          </div>

          {/* Tips Section */}
          <div className="mt-4 bg-gradient-to-r from-violet-500/10 to-fuchsia-500/10 dark:from-violet-500/20 dark:to-fuchsia-500/20 rounded-2xl border border-violet-200/50 dark:border-violet-500/20 p-4 sm:p-5">
            <h4 className="text-sm font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
              <span>💡</span> Tips for {subcategory.name}
            </h4>
            <ul className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 space-y-2">
              <li className="flex items-start gap-2">
                <span className="text-violet-500">•</span>
                Be specific about composition, lighting, and mood
              </li>
              <li className="flex items-start gap-2">
                <span className="text-violet-500">•</span>
                Include style modifiers like &ldquo;cinematic&rdquo; or &ldquo;high detail&rdquo;
              </li>
              <li className="flex items-start gap-2">
                <span className="text-violet-500">•</span>
                Mention camera settings for realistic results
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Back Button */}
      <div className="pt-4">
        <Link
          href={`/dashboard/image-generator/${categoryId}`}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-600 dark:text-slate-400 hover:text-violet-600 dark:hover:text-violet-400 transition-colors"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          Back to {category.name} Styles
        </Link>
      </div>
    </div>
  );
}
