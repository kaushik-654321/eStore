"use client";

import Link from "next/link";

const stats = [
  { label: "Images Created", value: "1,234", change: "+12%", icon: "🖼️", gradient: "from-violet-500 to-purple-500" },
  { label: "Audio Generated", value: "567", change: "+8%", icon: "🎵", gradient: "from-fuchsia-500 to-pink-500" },
  { label: "Videos Made", value: "89", change: "+23%", icon: "🎬", gradient: "from-orange-500 to-rose-500" },
  { label: "Credits Used", value: "4,521", change: "-5%", icon: "⚡", gradient: "from-amber-500 to-orange-500" },
];

const recentGenerations = [
  { type: "Image", name: "Sunset landscape", time: "2 mins ago", status: "completed" },
  { type: "Audio", name: "Podcast intro music", time: "15 mins ago", status: "completed" },
  { type: "Video", name: "Product demo", time: "1 hour ago", status: "processing" },
  { type: "Image", name: "Logo concept", time: "2 hours ago", status: "completed" },
];

const quickActions = [
  {
    title: "Image Generator",
    description: "Create stunning AI images from text",
    href: "/dashboard/image-generator",
    gradient: "from-violet-500 via-purple-500 to-fuchsia-500",
    shadowColor: "shadow-violet-500/40",
    icon: (
      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
      </svg>
    ),
  },
  {
    title: "Audio Generator",
    description: "Generate music and sound effects",
    href: "/dashboard/audio-generator",
    gradient: "from-fuchsia-500 via-pink-500 to-rose-500",
    shadowColor: "shadow-pink-500/40",
    icon: (
      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
      </svg>
    ),
  },
  {
    title: "Video Generator",
    description: "Create videos from prompts",
    href: "/dashboard/video-generator",
    gradient: "from-amber-500 via-orange-500 to-rose-500",
    shadowColor: "shadow-orange-500/40",
    icon: (
      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
      </svg>
    ),
  },
];

export default function DashboardPage() {
  return (
    <div className="space-y-6 sm:space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-violet-600 via-fuchsia-600 to-orange-500 rounded-2xl p-4 sm:p-8 text-white relative overflow-hidden shadow-xl shadow-violet-500/30">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iYSIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVHJhbnNmb3JtPSJyb3RhdGUoNDUpIj48cmVjdCB4PSIwIiB5PSIwIiB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIGZpbGw9InJnYmEoMjU1LDI1NSwyNTUsMC4wNSkiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IGZpbGw9InVybCgjYSkiIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiLz48L3N2Zz4=')] opacity-50"></div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-orange-500/30 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>
        <div className="relative">
          <h1 className="text-2xl sm:text-3xl font-bold mb-2">Welcome back! ✨</h1>
          <p className="text-violet-100 text-base sm:text-lg">Ready to create something amazing today?</p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6">
        {stats.map((stat, index) => (
          <div
            key={index}
            className="bg-white dark:bg-slate-900 rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-violet-100 dark:border-violet-500/20 hover:-translate-y-1 group"
          >
            <div className="flex items-center justify-between mb-2 sm:mb-4">
              <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br ${stat.gradient} flex items-center justify-center text-xl sm:text-2xl shadow-lg group-hover:scale-110 transition-transform`}>
                {stat.icon}
              </div>
              <span
                className={`text-xs sm:text-sm font-medium px-1.5 sm:px-2 py-0.5 sm:py-1 rounded-full ${
                  stat.change.startsWith("+")
                    ? "bg-emerald-100 text-emerald-600 dark:bg-emerald-500/20 dark:text-emerald-400"
                    : "bg-rose-100 text-rose-600 dark:bg-rose-500/20 dark:text-rose-400"
                }`}
              >
                {stat.change}
              </span>
            </div>
            <p className="text-xl sm:text-2xl font-bold text-slate-800 dark:text-white">{stat.value}</p>
            <p className="text-violet-600 dark:text-violet-400 text-xs sm:text-sm font-medium">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-lg sm:text-xl font-bold text-slate-800 dark:text-white mb-4 flex items-center gap-2">
          <span>🚀</span> Quick Actions
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {quickActions.map((action, index) => (
            <Link
              key={index}
              href={action.href}
              className={`group bg-white dark:bg-slate-900 rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-lg hover:shadow-2xl ${action.shadowColor} transition-all duration-300 border border-violet-100 dark:border-violet-500/20 hover:-translate-y-2`}
            >
              <div
                className={`w-12 h-12 sm:w-14 sm:h-14 rounded-xl bg-gradient-to-r ${action.gradient} flex items-center justify-center text-white mb-3 sm:mb-4 group-hover:scale-110 group-hover:rotate-3 transition-all shadow-lg`}
              >
                {action.icon}
              </div>
              <h3 className="text-base sm:text-lg font-semibold text-slate-800 dark:text-white mb-1 sm:mb-2 group-hover:text-violet-600 dark:group-hover:text-violet-400 transition-colors">{action.title}</h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm">{action.description}</p>
            </Link>
          ))}
        </div>
      </div>

      {/* Recent Generations */}
      <div className="bg-white dark:bg-slate-900 rounded-xl sm:rounded-2xl shadow-lg border border-violet-100 dark:border-violet-500/20 overflow-hidden">
        <div className="p-4 sm:p-6 border-b border-violet-100 dark:border-violet-500/20 bg-gradient-to-r from-violet-50 to-fuchsia-50 dark:from-violet-500/10 dark:to-fuchsia-500/10">
          <h2 className="text-lg sm:text-xl font-bold text-slate-800 dark:text-white flex items-center gap-2">
            <span>⚡</span> Recent Generations
          </h2>
        </div>
        <div className="divide-y divide-violet-100 dark:divide-violet-500/20">
          {recentGenerations.map((item, index) => (
            <div
              key={index}
              className="p-3 sm:p-4 hover:bg-violet-50 dark:hover:bg-violet-500/10 transition-colors flex items-center justify-between gap-3"
            >
              <div className="flex items-center gap-3 sm:gap-4 min-w-0">
                <div
                  className={`w-8 h-8 sm:w-10 sm:h-10 rounded-lg flex-shrink-0 flex items-center justify-center text-sm sm:text-base ${
                    item.type === "Image"
                      ? "bg-violet-100 text-violet-600 dark:bg-violet-500/20 dark:text-violet-400"
                      : item.type === "Audio"
                      ? "bg-fuchsia-100 text-fuchsia-600 dark:bg-fuchsia-500/20 dark:text-fuchsia-400"
                      : "bg-orange-100 text-orange-600 dark:bg-orange-500/20 dark:text-orange-400"
                  }`}
                >
                  {item.type === "Image" ? "🖼️" : item.type === "Audio" ? "🎵" : "🎬"}
                </div>
                <div className="min-w-0">
                  <p className="font-medium text-slate-800 dark:text-white text-sm sm:text-base truncate">{item.name}</p>
                  <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">{item.type} • {item.time}</p>
                </div>
              </div>
              <span
                className={`px-2 sm:px-3 py-0.5 sm:py-1 rounded-full text-xs sm:text-sm font-medium flex-shrink-0 ${
                  item.status === "completed"
                    ? "bg-emerald-100 text-emerald-600 dark:bg-emerald-500/20 dark:text-emerald-400"
                    : "bg-amber-100 text-amber-600 dark:bg-amber-500/20 dark:text-amber-400"
                }`}
              >
                {item.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
