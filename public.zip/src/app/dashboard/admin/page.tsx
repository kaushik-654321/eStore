"use client";

import Link from "next/link";

export default function AdminPage() {
  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 dark:from-blue-400 dark:to-cyan-400 bg-clip-text text-transparent">
          Admin Panel
        </h1>
        <p className="text-slate-600 dark:text-slate-400">
          Manage your items - Create, Update, and Delete operations
        </p>
      </div>

      {/* Admin Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Create Card */}
        <Link href="/dashboard/admin/create" className="group">
          <div className="p-6 bg-white dark:bg-slate-900/50 rounded-2xl border border-slate-200 dark:border-slate-700/50 hover:border-emerald-400 dark:hover:border-emerald-500/50 hover:shadow-lg hover:shadow-emerald-500/10 transition-all">
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-slate-800 dark:text-white mb-2">Create Item</h3>
            <p className="text-slate-600 dark:text-slate-400 text-sm">
              Add new items to your inventory or catalog
            </p>
          </div>
        </Link>

        {/* Update Card */}
        <Link href="/dashboard/admin/update" className="group">
          <div className="p-6 bg-white dark:bg-slate-900/50 rounded-2xl border border-slate-200 dark:border-slate-700/50 hover:border-blue-400 dark:hover:border-blue-500/50 hover:shadow-lg hover:shadow-blue-500/10 transition-all">
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-slate-800 dark:text-white mb-2">Update Item</h3>
            <p className="text-slate-600 dark:text-slate-400 text-sm">
              Modify existing items and update their details
            </p>
          </div>
        </Link>

        {/* Delete Card */}
        <Link href="/dashboard/admin/delete" className="group">
          <div className="p-6 bg-white dark:bg-slate-900/50 rounded-2xl border border-slate-200 dark:border-slate-700/50 hover:border-rose-400 dark:hover:border-rose-500/50 hover:shadow-lg hover:shadow-rose-500/10 transition-all">
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-rose-500 to-red-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-slate-800 dark:text-white mb-2">Delete Item</h3>
            <p className="text-slate-600 dark:text-slate-400 text-sm">
              Remove items from your inventory permanently
            </p>
          </div>
        </Link>
      </div>

      {/* Recent Activity */}
      <div className="bg-white dark:bg-slate-900/50 rounded-2xl border border-slate-200 dark:border-slate-700/50 p-6">
        <h2 className="text-xl font-semibold text-slate-800 dark:text-white mb-4">Recent Activity</h2>
        <div className="space-y-4">
          {[
            { action: "Created", item: "Product A", time: "2 hours ago", color: "emerald" },
            { action: "Updated", item: "Product B", time: "5 hours ago", color: "blue" },
            { action: "Deleted", item: "Product C", time: "1 day ago", color: "rose" },
          ].map((activity, index) => (
            <div key={index} className="flex items-center justify-between py-3 border-b border-slate-100 dark:border-slate-800 last:border-0">
              <div className="flex items-center gap-3">
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                  activity.color === "emerald" ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-400" :
                  activity.color === "blue" ? "bg-blue-100 text-blue-700 dark:bg-blue-500/20 dark:text-blue-400" :
                  "bg-rose-100 text-rose-700 dark:bg-rose-500/20 dark:text-rose-400"
                }`}>
                  {activity.action}
                </span>
                <span className="text-slate-700 dark:text-slate-300">{activity.item}</span>
              </div>
              <span className="text-sm text-slate-500 dark:text-slate-500">{activity.time}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
