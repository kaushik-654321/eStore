"use client";

import { useState } from "react";
import Link from "next/link";

const mockItems = [
  { id: 1, name: "Product A", category: "Electronics", price: 99.99, status: "active" },
  { id: 2, name: "Product B", category: "Clothing", price: 49.99, status: "active" },
  { id: 3, name: "Product C", category: "Food", price: 19.99, status: "inactive" },
  { id: 4, name: "Product D", category: "Electronics", price: 199.99, status: "draft" },
];

export default function UpdateItemPage() {
  const [selectedItem, setSelectedItem] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    category: "",
    price: "",
    status: "",
  });

  const handleSelectItem = (id: number) => {
    const item = mockItems.find((i) => i.id === id);
    if (item) {
      setSelectedItem(id);
      setFormData({
        name: item.name,
        category: item.category.toLowerCase(),
        price: item.price.toString(),
        status: item.status,
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Updating item:", { id: selectedItem, ...formData });
    alert("Item updated successfully!");
  };

  return (
    <div className="space-y-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm">
        <Link href="/dashboard/admin" className="text-slate-500 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
          Admin
        </Link>
        <span className="text-slate-400">/</span>
        <span className="text-slate-800 dark:text-white font-medium">Update Item</span>
      </div>

      {/* Page Header */}
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 dark:from-blue-400 dark:to-indigo-400 bg-clip-text text-transparent">
          Update Item
        </h1>
        <p className="text-slate-600 dark:text-slate-400">
          Select an item to update its details
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Items List */}
        <div className="bg-white dark:bg-slate-900/50 rounded-2xl border border-slate-200 dark:border-slate-700/50 p-6">
          <h2 className="text-lg font-semibold text-slate-800 dark:text-white mb-4">Select Item</h2>
          <div className="space-y-3">
            {mockItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleSelectItem(item.id)}
                className={`w-full p-4 rounded-xl border text-left transition-all ${
                  selectedItem === item.id
                    ? "border-blue-500 bg-blue-50 dark:bg-blue-500/10"
                    : "border-slate-200 dark:border-slate-700 hover:border-blue-300 dark:hover:border-blue-500/50"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium text-slate-800 dark:text-white">{item.name}</h3>
                    <p className="text-sm text-slate-500">{item.category}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-slate-800 dark:text-white">${item.price}</p>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      item.status === "active" ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-400" :
                      item.status === "inactive" ? "bg-slate-100 text-slate-700 dark:bg-slate-500/20 dark:text-slate-400" :
                      "bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-400"
                    }`}>
                      {item.status}
                    </span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Edit Form */}
        <div className="bg-white dark:bg-slate-900/50 rounded-2xl border border-slate-200 dark:border-slate-700/50 p-6">
          <h2 className="text-lg font-semibold text-slate-800 dark:text-white mb-4">Edit Details</h2>
          {selectedItem ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Category</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all"
                >
                  <option value="electronics">Electronics</option>
                  <option value="clothing">Clothing</option>
                  <option value="food">Food & Beverages</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Price</label>
                <input
                  type="number"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Status</label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all"
                >
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                  <option value="draft">Draft</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full px-6 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-blue-500/30 transition-all"
              >
                Update Item
              </button>
            </form>
          ) : (
            <div className="flex flex-col items-center justify-center h-64 text-slate-400">
              <svg className="w-16 h-16 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
              </svg>
              <p>Select an item to edit</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
