"use client";

import { useState } from "react";
import Link from "next/link";

const mockItems = [
  { id: 1, name: "Product A", category: "Electronics", price: 99.99, createdAt: "2024-01-15" },
  { id: 2, name: "Product B", category: "Clothing", price: 49.99, createdAt: "2024-02-20" },
  { id: 3, name: "Product C", category: "Food", price: 19.99, createdAt: "2024-03-10" },
  { id: 4, name: "Product D", category: "Electronics", price: 199.99, createdAt: "2024-03-25" },
];

export default function DeleteItemPage() {
  const [items, setItems] = useState(mockItems);
  const [selectedItems, setSelectedItems] = useState<number[]>([]);
  const [showConfirm, setShowConfirm] = useState(false);

  const toggleSelect = (id: number) => {
    setSelectedItems((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const selectAll = () => {
    if (selectedItems.length === items.length) {
      setSelectedItems([]);
    } else {
      setSelectedItems(items.map((i) => i.id));
    }
  };

  const handleDelete = () => {
    setItems((prev) => prev.filter((item) => !selectedItems.includes(item.id)));
    setSelectedItems([]);
    setShowConfirm(false);
    alert("Items deleted successfully!");
  };

  return (
    <div className="space-y-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm">
        <Link href="/dashboard/admin" className="text-slate-500 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
          Admin
        </Link>
        <span className="text-slate-400">/</span>
        <span className="text-slate-800 dark:text-white font-medium">Delete Item</span>
      </div>

      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-rose-600 to-red-600 dark:from-rose-400 dark:to-red-400 bg-clip-text text-transparent">
            Delete Items
          </h1>
          <p className="text-slate-600 dark:text-slate-400">
            Select items to remove from your inventory
          </p>
        </div>
        {selectedItems.length > 0 && (
          <button
            onClick={() => setShowConfirm(true)}
            className="px-6 py-3 bg-gradient-to-r from-rose-500 to-red-600 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-rose-500/30 transition-all"
          >
            Delete Selected ({selectedItems.length})
          </button>
        )}
      </div>

      {/* Items Table */}
      <div className="bg-white dark:bg-slate-900/50 rounded-2xl border border-slate-200 dark:border-slate-700/50 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 dark:bg-slate-800/50">
              <tr>
                <th className="px-6 py-4 text-left">
                  <input
                    type="checkbox"
                    checked={selectedItems.length === items.length && items.length > 0}
                    onChange={selectAll}
                    className="w-5 h-5 rounded border-slate-300 dark:border-slate-600 text-rose-500 focus:ring-rose-500"
                  />
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700 dark:text-slate-300">Name</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700 dark:text-slate-300">Category</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700 dark:text-slate-300">Price</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700 dark:text-slate-300">Created</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {items.map((item) => (
                <tr
                  key={item.id}
                  className={`transition-colors ${
                    selectedItems.includes(item.id)
                      ? "bg-rose-50 dark:bg-rose-500/10"
                      : "hover:bg-slate-50 dark:hover:bg-slate-800/50"
                  }`}
                >
                  <td className="px-6 py-4">
                    <input
                      type="checkbox"
                      checked={selectedItems.includes(item.id)}
                      onChange={() => toggleSelect(item.id)}
                      className="w-5 h-5 rounded border-slate-300 dark:border-slate-600 text-rose-500 focus:ring-rose-500"
                    />
                  </td>
                  <td className="px-6 py-4 text-slate-800 dark:text-white font-medium">{item.name}</td>
                  <td className="px-6 py-4 text-slate-600 dark:text-slate-400">{item.category}</td>
                  <td className="px-6 py-4 text-slate-800 dark:text-white">${item.price}</td>
                  <td className="px-6 py-4 text-slate-600 dark:text-slate-400">{item.createdAt}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {items.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 text-slate-400">
            <svg className="w-16 h-16 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
            </svg>
            <p>No items to display</p>
          </div>
        )}
      </div>

      {/* Confirm Modal */}
      {showConfirm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 max-w-md w-full mx-4 shadow-2xl">
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-rose-100 dark:bg-rose-500/20 flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-rose-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-slate-800 dark:text-white mb-2">Confirm Delete</h3>
              <p className="text-slate-600 dark:text-slate-400 mb-6">
                Are you sure you want to delete {selectedItems.length} item(s)? This action cannot be undone.
              </p>
              <div className="flex gap-4">
                <button
                  onClick={() => setShowConfirm(false)}
                  className="flex-1 px-4 py-3 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition-all"
                >
                  Cancel
                </button>
                <button
                  onClick={handleDelete}
                  className="flex-1 px-4 py-3 bg-gradient-to-r from-rose-500 to-red-600 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-rose-500/30 transition-all"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
