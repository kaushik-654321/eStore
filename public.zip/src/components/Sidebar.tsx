"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";

const menuItems = [
  {
    name: "Dashboard",
    href: "/dashboard",
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
      </svg>
    ),
  },
  {
    name: "AI Generators",
    href: "/dashboard/image-generator",
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
      </svg>
    ),
    hasSubmenu: true,
    submenu: [
      { name: "Image Generator", href: "/dashboard/image-generator", emoji: "🖼️" },
      { name: "Audio Generator", href: "/dashboard/audio-generator", emoji: "🎵" },
      { name: "Video Generator", href: "/dashboard/video-generator", emoji: "🎬" },
    ],
  },
  {
    name: "Payments History",
    href: "/dashboard/payments",
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
      </svg>
    ),
  },
  {
    name: "Checkout",
    href: "/dashboard/checkout",
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
      </svg>
    ),
  },
  {
    name: "Admin",
    href: "/dashboard/admin",
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
      </svg>
    ),
    hasSubmenu: true,
    submenu: [
      { name: "Create Item", href: "/dashboard/admin/create", emoji: "➕" },
      { name: "Update Item", href: "/dashboard/admin/update", emoji: "✏️" },
      { name: "Delete Item", href: "/dashboard/admin/delete", emoji: "🗑️" },
    ],
  },
  {
    name: "Manage Category",
    href: "/dashboard/categories",
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
      </svg>
    ),
  },
];

interface SidebarProps {
  isMobileOpen?: boolean;
  onMobileClose?: () => void;
}

export default function Sidebar({ isMobileOpen, onMobileClose }: SidebarProps) {
  const pathname = usePathname();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [expandedMenu, setExpandedMenu] = useState<string | null>(null);

  // Auto-expand submenu if current path matches
  useEffect(() => {
    menuItems.forEach((item) => {
      if (item.hasSubmenu && item.submenu) {
        const isSubmenuActive = item.submenu.some(sub => pathname.startsWith(sub.href));
        if (isSubmenuActive) {
          setExpandedMenu(item.name);
        }
      }
    });
  }, [pathname]);

  // Close mobile menu when route changes
  useEffect(() => {
    if (onMobileClose) {
      onMobileClose();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname]);

  return (
    <>
      {/* Mobile Overlay */}
      {isMobileOpen && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden"
          onClick={onMobileClose}
        />
      )}
      
      <aside
        className={`
          fixed lg:static inset-y-0 left-0 z-50
          ${isCollapsed ? "lg:w-20" : "lg:w-72"} 
          ${isMobileOpen ? "translate-x-0 w-72" : "-translate-x-full lg:translate-x-0"}
          bg-gradient-to-b from-slate-900 via-blue-950 to-indigo-950 dark:from-slate-950 dark:via-blue-950 dark:to-indigo-950
          min-h-screen transition-all duration-300 ease-in-out flex flex-col border-r border-blue-500/20
        `}
      >
      {/* Logo */}
      <div className="p-6 border-b border-blue-500/20">
        <div className="flex items-center justify-between">
          {(!isCollapsed || isMobileOpen) && (
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-400 via-blue-500 to-indigo-500 flex items-center justify-center shadow-lg shadow-blue-500/40 animate-pulse">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-blue-300 via-cyan-300 to-white bg-clip-text text-transparent">
                AI Studio
              </h1>
            </div>
          )}
          {/* Close button for mobile */}
          <button
            onClick={onMobileClose}
            className="lg:hidden p-2 rounded-lg hover:bg-blue-500/20 transition-colors text-blue-300 hover:text-white"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
          {/* Collapse button for desktop */}
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="hidden lg:block p-2 rounded-lg hover:bg-blue-500/20 transition-colors text-blue-300 hover:text-white"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {isCollapsed ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 5l7 7-7 7M5 5l7 7-7 7" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 19l-7-7 7-7m8 14l-7-7 7-7" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        <p className={`text-xs font-semibold text-blue-400/70 uppercase tracking-wider mb-4 ${isCollapsed && !isMobileOpen ? "hidden" : ""}`}>
          Main Menu
        </p>
        {menuItems.map((item) => {
          const isActive = pathname === item.href || (item.hasSubmenu && item.submenu?.some(sub => pathname.startsWith(sub.href)));
          const isExpanded = expandedMenu === item.name;
          const shouldShowText = !isCollapsed || isMobileOpen;
          
          if (item.hasSubmenu) {
            return (
              <div key={item.name}>
                <button
                  onClick={() => setExpandedMenu(isExpanded ? null : item.name)}
                  className={`w-full flex items-center ${
                    shouldShowText ? "gap-3" : "justify-center"
                  } px-4 py-3.5 rounded-xl transition-all duration-200 group relative overflow-hidden ${
                    isActive
                      ? "bg-gradient-to-r from-blue-500/30 to-indigo-500/30 text-white"
                      : "text-blue-300 hover:bg-blue-500/20 hover:text-white"
                  }`}
                  title={!shouldShowText ? item.name : undefined}
                >
                  <span className={`relative ${isActive ? "text-white" : "group-hover:scale-110"} transition-transform`}>
                    {item.icon}
                  </span>
                  {shouldShowText && (
                    <>
                      <span className="relative font-medium flex-1 text-left">{item.name}</span>
                      <svg 
                        className={`w-4 h-4 transition-transform ${isExpanded ? "rotate-180" : ""}`} 
                        fill="none" 
                        stroke="currentColor" 
                        viewBox="0 0 24 24"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    </>
                  )}
                </button>
                
                {/* Submenu */}
                {shouldShowText && isExpanded && item.submenu && (
                  <div className="mt-2 ml-4 pl-4 border-l border-blue-500/30 space-y-1">
                    {item.submenu.map((subItem) => {
                      const isSubActive = pathname.startsWith(subItem.href);
                      return (
                        <Link
                          key={subItem.name}
                          href={subItem.href}
                          className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 ${
                            isSubActive
                              ? "bg-gradient-to-r from-blue-500 via-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-500/30"
                              : "text-blue-300 hover:bg-blue-500/20 hover:text-white"
                          }`}
                        >
                          <span className="text-base">{subItem.emoji}</span>
                          <span className="text-sm font-medium">{subItem.name}</span>
                          {isSubActive && (
                            <div className="ml-auto w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                          )}
                        </Link>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          }
          
          return (
            <Link
              key={item.name}
              href={item.href}
              className={`flex items-center ${
                shouldShowText ? "gap-3" : "justify-center"
              } px-4 py-3.5 rounded-xl transition-all duration-200 group relative overflow-hidden ${
                isActive
                  ? "bg-gradient-to-r from-blue-500 via-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-500/40"
                  : "text-blue-300 hover:bg-blue-500/20 hover:text-white"
              }`}
              title={!shouldShowText ? item.name : undefined}
            >
              {isActive && (
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-indigo-500/20 blur-xl" />
              )}
              <span className={`relative ${isActive ? "text-white" : "group-hover:scale-110"} transition-transform`}>
                {item.icon}
              </span>
              {shouldShowText && <span className="relative font-medium">{item.name}</span>}
              {isActive && shouldShowText && (
                <div className="absolute right-3 w-2 h-2 rounded-full bg-white shadow-lg shadow-white/50 animate-pulse" />
              )}
            </Link>
          );
        })}
      </nav>

      {/* User Profile */}
      <div className="p-4 border-t border-blue-500/20">
        <div className={`flex items-center ${isCollapsed && !isMobileOpen ? "justify-center" : "gap-3"} p-2 rounded-xl bg-gradient-to-r from-blue-500/10 to-indigo-500/10 border border-blue-500/20`}>
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-400 via-blue-500 to-indigo-500 flex items-center justify-center text-white font-bold shadow-lg shadow-blue-500/40">
            U
          </div>
          {(!isCollapsed || isMobileOpen) && (
            <div className="flex-1">
              <p className="text-sm font-semibold text-white">User Name</p>
              <div className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse online-pulse" />
                <p className="text-xs text-amber-400 font-medium">Pro Plan ⭐</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </aside>
    </>
  );
}