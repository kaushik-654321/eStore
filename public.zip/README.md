# AI Studio - Next.js SaaS Dashboard

A modern SaaS dashboard template built with Next.js 14, TypeScript, and Tailwind CSS. Features AI content generation tools including Image, Audio, and Video generators.

## Features

- 🎨 **Modern UI** - Clean, responsive design with Tailwind CSS
- 🖼️ **Image Generator** - Create AI-powered images with style and size options
- 🎵 **Audio Generator** - Generate music and audio with genre and mood settings
- 🎬 **Video Generator** - Create videos with quality and aspect ratio controls
- 📱 **Responsive Sidebar** - Collapsible navigation menu
- 🌙 **Interactive Components** - Loading states, progress bars, and hover effects

## Getting Started

First, run the development server:

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## Project Structure

```
src/
├── app/
│   ├── dashboard/
│   │   ├── image-generator/
│   │   │   └── page.tsx
│   │   ├── audio-generator/
│   │   │   └── page.tsx
│   │   ├── video-generator/
│   │   │   └── page.tsx
│   │   ├── layout.tsx
│   │   └── page.tsx
│   ├── layout.tsx
│   ├── page.tsx
│   └── globals.css
├── components/
│   ├── Sidebar.tsx
│   └── Header.tsx
```

## Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **Fonts**: Geist Sans & Geist Mono

## Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run lint` - Run ESLint

## Customization

### Adding New Pages

1. Create a new folder under `src/app/dashboard/`
2. Add a `page.tsx` file with your component
3. Add the route to the sidebar in `src/components/Sidebar.tsx`

### Styling

The project uses Tailwind CSS. Customize the theme in `tailwind.config.ts`.

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

## Deploy on Vercel

The easiest way to deploy your Next.js app is to use the [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme) from the creators of Next.js.

Check out our [Next.js deployment documentation](https://nextjs.org/docs/app/building-your-application/deploying) for more details.
